package chapter3;

import java.util.function.Predicate;

public class Sect5e_Ex1 {

    public static void main(String[] args) {
        Predicate<Integer> p3;
        p3 =  x -> x > 7;

        //System.out.println(p1.and(Predicate.not(x -> x % 2 == 1)).test(8));
        Predicate<Integer> p1 = x -> x > 7;

        if (p1.test(9)) {
            System.out.println("Predicate x > 7 is true for x==9.");
        } else {
            System.out.println("Predicate x > 7 is false for x==9.");
        }

        if (p1.test(3)) {
            System.out.println("Predicate x > 7 is true for x==3.");
        } else {
            System.out.println("Predicate x > 7 is false for x==3.");
        }

    }
}
