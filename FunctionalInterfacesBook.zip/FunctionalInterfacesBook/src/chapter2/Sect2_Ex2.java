package chapter2;
public class Sect2_Ex2 
{    
    public static void main(String[] args)
    {
        FIVoid LambdaVoid = x -> System.out.println(x);
        LambdaVoid.method1(5);
    }
}
