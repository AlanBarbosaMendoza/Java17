package chapter2;
public class Sect4_Ex2 
{
    public static void main(String[] args)
    {
        FI3 FI3Lambda1 = () -> 99;
        System.out.println(FI3Lambda1.method1());
    }
}
