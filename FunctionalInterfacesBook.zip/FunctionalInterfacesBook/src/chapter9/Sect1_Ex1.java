package chapter9;
import java.util.*;
import java.util.function.Predicate;
public class Sect1_Ex1 
{
    public static void main(String[] args)
    {
        
        
        Predicate<String> evalua = x -> x.charAt(0) == 'S';
        
        if(evalua.test("Valor")){
            
            System.out.println("La palabra inicia con S");
        
        }else{
            System.out.println("La palabra NO inicia con S");
        }
        
        
        ArrayList<String> list = new ArrayList<>();
        list.add("Super");
        list.add("Random");
        list.add("Silly");
        list.add("Strings");
        
        list.removeIf(x -> x.charAt(0) == 'S');
        list.forEach(x -> System.out.println(x));
    }
}
