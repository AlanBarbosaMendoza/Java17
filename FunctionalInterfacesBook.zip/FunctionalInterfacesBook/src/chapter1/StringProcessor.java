package chapter1;


@FunctionalInterface
public interface StringProcessor {

    String process(String x);
    
   
    

}
