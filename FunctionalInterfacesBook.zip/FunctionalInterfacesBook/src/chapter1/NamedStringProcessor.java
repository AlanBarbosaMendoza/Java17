package chapter1;
public class NamedStringProcessor implements StringProcessor 
{
    @Override
    public String process(String s) { 
        
        return s.toUpperCase(); 
    
    }
}
