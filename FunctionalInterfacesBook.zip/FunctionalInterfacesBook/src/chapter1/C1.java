package chapter1;
public class C1 implements I1
{
    @Override 
    public void method1() {}
    @Override 
    public String method2(String x) { return x; }
}
