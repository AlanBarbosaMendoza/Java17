/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chapter1;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 *
 * @author alanbarbosamendoza
 */
public class UseReceiptPrinter {

    public static void main(String[] args) {
    
        ReceiptPrinter simpleReceiptPrinterEn = new ReceiptPrinter(){
            @Override
            public void print(Receipt receipt) {
                System.out.println("Item :: "+ receipt.item);
                System.out.println("Price :: "+ receipt.price);
                System.out.println("Discount :: "+ receipt.discount);
                System.out.println("TX :: "+ receipt.tax);
                System.out.println("Total :: "+ computeTotal(receipt));
                
            }
        
        };
        
         ReceiptPrinter simpleReceiptPrinterSp = new ReceiptPrinter(){
            @Override
            public void print(Receipt receipt) {
                System.out.println("Artículo :: "+ receipt.item);
                System.out.println("Precio :: "+ receipt.price);
                System.out.println("Descuento :: "+ receipt.discount);
                System.out.println("Impuesto :: "+ receipt.tax);
                System.out.println("Total :: "+ computeTotal(receipt));
                
            }
        
        };
        
        
        Receipt receipt = new Receipt("shirt", 20.00, 0.05, 0.07); 
        simpleReceiptPrinterEn.print(receipt); 
        
        
        simpleReceiptPrinterSp.print(receipt); 
        
        List<String> lista=Arrays.asList("hola","que","tal");
        
        System.out.println("Impresión lambda");
        lista.stream().forEach((x)->System.out.println(x));
        
        //Consumer
        
        List<String> lista2=Arrays.asList("hola","que","tal");
        
        
        
   


        
        System.out.println("Impresión lambada 2");
    metodo((Receipt x) -> System.out.println(x.discount));
    }
    
    public static void metodo(ReceiptPrinter interfaceEjemplo){
        
    }
    

    

    
}
