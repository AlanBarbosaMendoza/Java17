/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chapter1;

/**
 *
 * @author alanbarbosamendoza
 */
interface I4 {

    private static String getPrefix(String p) {
        return p.equals("male") ? "Mr. " : "Ms. ";
    }

    public static String getName(String n, String p) {
        return getPrefix(p) + n;
    }
}

class TestI4 {

    public static void main(String[] args) {
        System.out.println(I4.getName("Smith", "female"));
        System.out.println(I4.getName("Jones", "male"));
    }
}
