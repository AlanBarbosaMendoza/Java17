/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.javarobot;

/**
 *
 * @author alanbarbosamendoza
 */
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;

public class Move {

    static int keyInput[] = {KeyEvent.VK_J, KeyEvent.VK_A, KeyEvent.VK_V,
        KeyEvent.VK_A, KeyEvent.VK_SPACE, KeyEvent.VK_M, KeyEvent.VK_U, KeyEvent.VK_C, KeyEvent.VK_H,KeyEvent.VK_A,KeyEvent.VK_C,KeyEvent.VK_H,KeyEvent.VK_O,KeyEvent.VK_S};

    public static void move(int x, int y) throws AWTException {
        Robot bot = new Robot();
        bot.mouseMove(x, y);
    }

    public static void main(String[] args) throws AWTException, InterruptedException {
        System.out.println("Move Mouse Started");
        String arg1 = "1";//args[0]; //totalMinutes
        String arg2 = "10";//args[1]; //interval

       
        Robot robot = new Robot();
        for (int i = 0; i < keyInput.length; i++) {
            robot.keyPress(keyInput[i]);
            robot.delay(1000);
        }

        System.out.println(
                "arg1..=" + arg1 + "    arg2..:" + arg2);
        int totalMinutes = Integer.parseInt(arg1);
        int interval = Integer.parseInt(arg2);
        for (int i = 0;
                i < totalMinutes;
                i++) {
            move(100, 100);
            TimeUnit.MINUTES.sleep(interval);
            System.out.println("Loop...:" + (i + 1));
        }
    }
}
