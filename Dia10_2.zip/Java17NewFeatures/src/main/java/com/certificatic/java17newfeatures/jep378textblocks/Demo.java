package com.certificatic.java17newfeatures.jep378textblocks;

public class Demo {
  public static void main(String[] args) {
    var text1 = """
"This is the end, my only friend, the end", said a wise man once.
                        "Who", asked the jester.
"Je", said the king.
 """;

    System.out.println(text1);
  }
}
