/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.main;

import com.certificatic.model.Factura;
import java.util.Date;

/**
 *
 * @author alanbarbosamendoza
 */
public class DemoImpuestos {
     public static void main(String[] args) {
        Factura factura = new Factura();
        factura.setIdFactura(1);
        factura.setfFactura(new Date());
        factura.setSubtotal(10000);
        double iva = factura.getIva();
        System.out.println("El iva es :::: "+iva);
        
        
         System.out.println(" Hola mundo!!!!!");
        
        // double isr = ImpuestosUtil.calcularIsr(factura.getSubtotal());
    }
}
