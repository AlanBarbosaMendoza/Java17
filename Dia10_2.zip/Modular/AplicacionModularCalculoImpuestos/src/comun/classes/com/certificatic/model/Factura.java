/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.model;

import com.certificatic.util.ImpuestosUtil;
import java.util.Date;

/**
 *
 * @author alanbarbosamendoza
 */
public class Factura {
    
    private int idFactura;
    private double subtotal;
    private double iva;
    private Date fFactura;

    /**
     * @return the idFactura
     */
    public int getIdFactura() {
        return idFactura;
    }

    /**
     * @param idFactura the idFactura to set
     */
    public void setIdFactura(int idFactura) {
        this.idFactura = idFactura;
    }

    /**
     * @return the subtotal
     */
    public double getSubtotal() {
        return subtotal;
    }

    /**
     * @param subtotal the subtotal to set
     */
    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }

    /**
     * @return the iva
     */
    public double getIva() {
        
        return ImpuestosUtil.calcularIva(subtotal);
    }

    /**
     * @return the fFactura
     */
    public Date getfFactura() {
        return fFactura;
    }

    /**
     * @param fFactura the fFactura to set
     */
    public void setfFactura(Date fFactura) {
        this.fFactura = fFactura;
    }
    
}
