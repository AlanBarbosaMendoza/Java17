/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.principal.main;

import com.certificatic.model.Factura;
import com.certificatic.util.ImpuestosUtil;

import java.util.Date;

/**
 *
 * @author alanbarbosamendoza
 */
public class DemoCalculoImpuestos {
    
    public static void main(String[] args) {
        Factura factura = new Factura();
        factura.setIdFactura(1);
        factura.setfFactura(new Date());
        factura.setSubtotal(10000);
        double iva = factura.getIva();
        System.out.println("El iva es :::: "+iva);
        
        //ImpuestosUtil iu = new ImpuestosUtil();
        
         double isr = ImpuestosUtil.calcularIsr(factura.getSubtotal());
    }
    
}
