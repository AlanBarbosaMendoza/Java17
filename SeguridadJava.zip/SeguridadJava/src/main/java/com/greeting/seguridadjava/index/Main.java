/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.greeting.seguridadjava.index;

import java.util.ArrayList;
import java.util.Arrays;
import static java.util.Objects.checkFromIndexSize;
import static java.util.Objects.checkFromToIndex;
import static java.util.Objects.checkIndex;

/**
 *
 * @author alanbarbosamendoza
 */
public class Main {

    public static void main(String[] args) {

    }

    public static void checkIndexUse() {

        int[] array = {1, 2, 3, 4, 5};

        int index = 3;
        try {
            checkIndex(index, array.length);
            System.out.println("Element at index " + index + ": " + array[index]);
        } catch (IndexOutOfBoundsException e) {
            System.err.println("Invalid index: " + index);
        }
    }

    public static void checkFromToIndexUse() {

        String[] names = {"Alice", "Bob", "Charlie", "David", "Emily"};

        int fromIndex = 1;
        int toIndex = 3;
        try {
            checkFromToIndex(fromIndex, toIndex, names.length);
            System.out.println("Sublist from index " + fromIndex + " to index " + (toIndex - 1) + ": " + Arrays.asList(names).subList(fromIndex, toIndex));
        } catch (IndexOutOfBoundsException e) {
            System.err.println("Invalid index range: " + fromIndex + "-" + toIndex);
        }

    }

    public static void checkFromToIndexSizeUse() {

        ArrayList<Integer> list = new ArrayList<>();
        list.add(10);
        list.add(20);
        list.add(30);

        int fromIndex = 1;
        int size = 2;
        try {
            checkFromIndexSize(fromIndex, size, list.size());
            list.addAll(fromIndex, Arrays.asList(40, 50));
            System.out.println("Updated list: " + list);
        } catch (IndexOutOfBoundsException e) {
            System.err.println("Invalid index: " + fromIndex);
        } catch (IllegalArgumentException e) {
            System.err.println("Invalid size: " + size);
        }

    }

}
