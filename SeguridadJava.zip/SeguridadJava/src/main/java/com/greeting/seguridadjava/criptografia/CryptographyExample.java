/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.greeting.seguridadjava.criptografia;

/**
 *
 * @author alanbarbosamendoza
 */
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

public class CryptographyExample {

    public static void main(String[] args) throws Exception {
        // Generamos una clave secreta para el algoritmo de cifrado AES.
        KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
        SecretKey secretKey = keyGenerator.generateKey();

        // Creamos un objeto Cipher para cifrar y descifrar los datos.
        Cipher cipher = Cipher.getInstance("AES");

        // Iniciamos el cifrado.
        cipher.init(Cipher.ENCRYPT_MODE, secretKey);

        // Ciframos los datos.
        byte[] encryptedData = cipher.doFinal("Hola, mundo".getBytes());

        // Iniciamos el descifrado.
        cipher.init(Cipher.DECRYPT_MODE, secretKey);

        // Desciframos los datos.
        byte[] decryptedData = cipher.doFinal(encryptedData);

        // Imprimimos los datos descifrados.
        System.out.println(new String(decryptedData));
    }
}
