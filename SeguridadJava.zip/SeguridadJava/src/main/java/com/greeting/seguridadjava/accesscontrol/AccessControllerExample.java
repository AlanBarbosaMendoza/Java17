/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.greeting.seguridadjava.accesscontrol;

/**
 *
 * @author alanbarbosamendoza
 */
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.security.PrivilegedActionException;

public class AccessControllerExample {

    public static void main(String[] args) {
        String filename = "/Library/Java/JavaVirtualMachines/jdk-17.0.3.1.jdk/Contents/Home/bin/mi-certificado.jks";
        File file = new File(filename);

        if (!file.exists()) {
            System.out.println("El archivo " + filename + " no existe.");
            return;
        }

        if (!file.canRead()) {
            System.out.println("No tiene permisos para leer el archivo " + filename + ".");
            return;
        }

        AccessController.doPrivileged((PrivilegedAction<Void>) () -> {
            try {
                try (FileReader reader = new FileReader(filename)) {
                    BufferedReader bufferedReader = new BufferedReader(reader);
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        System.out.println(line);
                    }
                    bufferedReader.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        });
    }
}
