/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.greeting.seguridadjava;

/**
 *
 * @author alanbarbosamendoza
 */
public class SeguridadJava {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
