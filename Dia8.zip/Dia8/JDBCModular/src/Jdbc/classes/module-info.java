/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

module Jdbc {
    
    requires java.sql;
    requires java.sql.rowset;
    requires org.apache.derby.client;
    requires org.apache.derby.commons;
    requires org.apache.derby.engine;
}
