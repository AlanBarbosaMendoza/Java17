package jdbc.ejemplo.server.simple.test.insert;

import jdbc.ejemplo.server.simple.test.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

public class SimpleJDBCTestInsert {

    public static void main(String[] args) {
        String url = "jdbc:derby://localhost:1527/ProductsDB";
        String username = "tiger";
        String password = "scott";

        try (Connection con = DriverManager.getConnection(url, null, null)) {
            System.out.println("Ingresamos");
            Statement stmt = con.createStatement();
            String query = "Insert into EMPLOYEE values (1507,'Juanito2','Perez','1950-09-21', 150000)";
           
            if (stmt.executeUpdate(query) > 0) {
                System.out.println("A new Employee record is added");
            }
            String query1 ="select * from Employee";
            ResultSet rs = stmt.executeQuery(query1);

            while (rs.next()) {
                int empID = rs.getInt("ID");
                String first = rs.getString("FirstName");
                String last = rs.getString("LastName");
                Date birthDate = rs.getDate("BirthDate");
                float salary = rs.getFloat("Salary");
                System.out.println("Employee ID:   " + empID + "\n"
                        + "Employee Name: " + first + " " + last + "\n"
                        + "Birth Date:    " + birthDate + "\n"
                        + "Salary:        " + salary + "\n");
            } // end of while
        } catch (SQLException ex) {
            while (ex != null) {
                System.out.println("SQLState:  " + ex.getSQLState());
                System.out.println("Error Code:" + ex.getErrorCode());
                System.out.println("Message:   " + ex.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause:" + t);
                    t = t.getCause();
                }
                ex = ex.getNextException();
            }
        }
    }
}
