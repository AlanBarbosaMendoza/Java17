package jdbc.ejemplo.server.callablestatement;

import jdb.ejemplo.preparedStatement.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CallableStatementTest {

    public static void main(String[] args) {
        String url = "jdbc:derby://localhost:1527/ProductsDB";
        String username = "tiger";
        String password = "scott";
        String input = "";
        double searchValue;
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        try (Connection con = DriverManager.getConnection(url, null, null)) {

            CallableStatement cStmt
                    = con.prepareCall("{CALL APP.MYCREATETEEMP (?, ?, ?, ?, ?)}");
            

            int id = 1257;
            String firstname = "Juanita";
            String lastname = "Perez";
            String birthday = "1995-07-11";
            double salary = 121200;

            cStmt.setInt(1, id);
            cStmt.setString(2, firstname);
            cStmt.setString(3, lastname);
            cStmt.setString(4, birthday);
            cStmt.setDouble(5, salary);

            boolean result = cStmt.execute();
            //int count = cStmt.getInt(1);

            System.out.println("result :: "+result);

// 
        } catch (NumberFormatException n) {
            System.out.println("Please enter a valid number.");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("SQLException: " + e);
        } // end of try-with-resources
    }
}
