/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package derbysp;

/**
 *
 * @author alanbarbosamendoza
 */

import java.sql.*;
import static java.lang.System.*;


public class DerbySP {
    
    public static void createNewEmp(int id, String firstname, String lastname, String birthday, double salary ){
        
        String url= "jdbc:default:connection";
        Connection con = null;
        
        try {
            
            
            con = DriverManager.getConnection(url);
            String query = "Insert into EMPLOYEE values (?,?,?,?,?)";
            PreparedStatement ps;
            ps = con.prepareStatement(query);
            ps.setInt(1, id);
            ps.setString(2, firstname);
            ps.setString(3, lastname);
            ps.setString(4, birthday);
            ps.setDouble(5, id);
            int result= ps.executeUpdate();
            out.print(result + " registros insertados");
            
            
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
        
            try {
                if(con != null) con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    
    }
    
}
