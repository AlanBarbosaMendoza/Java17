package com.example.format;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Locale;

public class DateFormatTest {
  public static void main(String[] args) {
    
    LocalDateTime today = LocalDateTime.now();
    Locale loc = Locale.ENGLISH;
    
    DateTimeFormatter df = 
      DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG)
        .withLocale(loc);
    System.out.println("Date: " + today.format(df) 
        + " Locale: " + loc.toString());
  }
}