/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Record.java to edit this template
 */
package com.certificatic.records.ej1;

/**
 *
 * @author alanbarbosamendoza
 */
public record AlumnoDTO(String nombre, int edad) {

    public AlumnoDTO(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
        Animal animal = new Animal("doberman","tranquilo");
        animal.raza();
    }
    
    
    public AlumnoDTO(String nombre) {
            this(nombre, 18);
    }
    
    public void dameEdad(){
        System.out.println("la edad es :: "+ edad);
    }
   
}


 record Animal(String raza, String tipo){

}
