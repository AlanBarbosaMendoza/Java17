/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.certificatic.records.ej1;

/**
 *
 * @author alanbarbosamendoza
 */
public class UsaAlumno {
    
    public static void main(String[] args) {
        
        AlumnoDTO alumno = new AlumnoDTO("Juanito", 30);
        System.out.println("El nombre del alumno es :: "+alumno.nombre());
        System.out.println("La edad del alumno es :: "+alumno.edad());
       
        Animal animal = new Animal("Pato", "Feo");
        System.out.println("animal "+ animal);
        
        
        alumno.dameEdad();
        
        AlumnoDTO alumno2 = new AlumnoDTO("Pepe", 20);
        
        System.out.println(alumno2);

        
    }
    
}
