/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.certificatic.records.ej1;

/**
 *
 * @author alanbarbosamendoza
 */
public class UsaPersona {
    
    public static void main(String[] args) {
        Persona persona = new Persona("Pepito", 25);
        persona.getNombre();
        persona.getEdad();
        System.out.println("Persona :: "+ persona);
        
        PersonaDTO personaDto = new PersonaDTO("Mary", 35);
        personaDto.nombre();
        personaDto.edad();
        System.out.println("PersonaDTO :: "+ personaDto);
               
    }
    
}
