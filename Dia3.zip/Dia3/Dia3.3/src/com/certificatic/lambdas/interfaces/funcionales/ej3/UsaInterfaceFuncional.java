/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.lambdas.interfaces.funcionales.ej3;

/**
 *
 * @author alanbarbosamendoza
 */
public class UsaInterfaceFuncional implements PruebaString {

    @Override
    public boolean prueba(String arg0, String arg1) {
        
        System.out.println("arg 0 :: "+ arg0 + " arg 1 :: "+arg1  );
        
        return true;
    }
    
    
    public static void main(String[] args) {
        
        UsaInterfaceFuncional imprimerString  = new UsaInterfaceFuncional();
        imprimerString.prueba("argumento 1 ", "argumento 2");
   
        
    }
}
