/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.lambdas.interfaces.funcionales.ej1;

/**
 *
 * @author alanbarbosamendoza
 */

@FunctionalInterface
public interface MiValParam {
    double getValor(double v);

}
