/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.lambdas.interfaces.funcionales.ej4;

/**
 *
 * @author alanbarbosamendoza
 */
public class LambdaDemo {
     public static void main(String[] args) {
        // Este bloque lambda devuelve el divisor positivo más pequeño de un valor
        FuncNum divPeq= (n) ->{
            int res=1;
            // Obtenga el valor absoluto de n.
            n = n<0 ? -n:n;
            for (int i=2; i<=n/i;i++)
                if ((n%i)==0) {
                    res = i;
                    break;
                }
            return res;
        };
         System.out.println("El divisor más pequeño de 12 es: "+divPeq.func(12));
         System.out.println("El divisor más pequeño de 15 es: "+divPeq.func(-15));
    }
}
