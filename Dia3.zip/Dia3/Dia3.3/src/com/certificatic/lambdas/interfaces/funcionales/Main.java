/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.lambdas.interfaces.funcionales;

import java.util.function.Predicate;

/**
 *
 * @author alanbarbosamendoza
 */
public class Main {
    
    public static void main(String[] args) {

        Predicate<Integer> p1 = x -> x > 17; 
        System.out.println(p1.or(x -> x < 3).test(9));
    }
    
}
