/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.lambdas.interfaces.funcionales.ej3;

/**
 *
 * @author alanbarbosamendoza
 */
@FunctionalInterface
public interface PruebaString {
    
    boolean prueba(String sa, String sb);

    private void metodo2(){
        
        System.out.println("Imprime");
            
    }
    
    default void usaMeotodo2(){
        metodo2();
    }
}
