package com.certificatic.lambdas.interfaces.funcionales.intro.cap2;
@FunctionalInterface
public interface FIVoid 
{
    void method1(int i);
}
