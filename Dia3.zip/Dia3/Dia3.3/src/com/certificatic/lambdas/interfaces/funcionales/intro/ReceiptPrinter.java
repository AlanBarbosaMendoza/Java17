/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.lambdas.interfaces.funcionales.intro;

/**
 *
 * @author alanbarbosamendoza
 */
@FunctionalInterface
interface ReceiptPrinter {

    void print(Receipt receipt);

    private double getDiscountedPrice(Receipt receipt) {
        return receipt.price
                - (receipt.price * receipt.discount);
    }

    default double computeTotal(Receipt receipt) {
        double discountedPrice = getDiscountedPrice(receipt);
        return discountedPrice + (discountedPrice * receipt.tax);
    }
}
