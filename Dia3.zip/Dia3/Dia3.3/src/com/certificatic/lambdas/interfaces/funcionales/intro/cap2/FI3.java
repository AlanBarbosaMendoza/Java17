package com.certificatic.lambdas.interfaces.funcionales.intro.cap2;
@FunctionalInterface
public interface FI3 
{
    Integer method1();
}
