/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.lambdas.interfaces.funcionales.intro;

/**
 *
 * @author alanbarbosamendoza
 */
public class UseReceiptPrint {
    
    public static void main(String[] args) {
        
        StringProcessor  sp = new StringProcessorImpl();
        String saludo = sp.process("Juanito Caminante");
        //System.out.println(saludo);
        
        StringProcessor sp2 = new StringProcessorImplDesp();
        String saludo2 = sp2.process("Juanito Caminante");
        //System.out.println(saludo2);
        
        
        StringProcessor sp3 = new StringProcessor() {
            @Override
            public String process(String x) {
                return "Buenos dias " + x;
            }
        };
        
        String saludo3 = sp3.process("Equipo");
        //System.out.println(saludo3);
        
        ///////
        
        saludar(s -> "Buenos dias "+ s , "Equipo");
        saludar(s -> "Buenos tardes "+ s, "Equipo");
        saludar(s -> "Buenos noches "+ s, "Equipo");
        
       
        
    }
    
    
    public static void saludar(StringProcessor sp, String nombre){

         System.out.println(sp.process(nombre));
    
    }
    
}
