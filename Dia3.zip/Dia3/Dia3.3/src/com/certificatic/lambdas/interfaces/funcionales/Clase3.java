/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.lambdas.interfaces.funcionales;

import java.util.function.Predicate;

/**
 *
 * @author alanbarbosamendoza
 */
public class Clase3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        validar( x -> true);
     
    }
    
    public static void validar(Predicate p){
    
    
    }
    
}
