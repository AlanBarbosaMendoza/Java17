package com.certificatic.lambdas.interfaces.funcionales.intro.cap2;
@FunctionalInterface
public interface StringProcessor 
{
       String process(String x);
}
