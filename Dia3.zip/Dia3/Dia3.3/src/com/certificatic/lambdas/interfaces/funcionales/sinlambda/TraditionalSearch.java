/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.lambdas.interfaces.funcionales.sinlambda;

import java.util.ArrayList;
import java.util.List;
import javax.swing.SpringLayout;

/**
 *
 * @author alanbarbosamendoza
 */
public class TraditionalSearch {

    public static void main(String[] args) {
        List<Animal> animals = new ArrayList<Animal>(); // list of animals animals.add(new Animal("fish", false, true));
        animals.add(new Animal("kangaroo", true, false));
        animals.add(new Animal("rabbit", true, false));
        animals.add(new Animal("turtle", false, true)); 
        
        CheckTrait ifHopper = new CheckIfHopper();
      
        
        print(animals, ifHopper); // pass class that does check 
        
        
        CheckTrait ifHopper2 = (Animal a) -> {
                System.out.println(" metodo anónimo");
                return true;
            };
        
        
        
        print(animals, new CheckTrait() {
            @Override
            public boolean test(Animal a) {
                return true;
            }
        });
        
        print(animals, 
                (Animal o) -> {
                    return o.canHop();
                }
        );
        print(animals,  o -> o.canSwim());
        
    }


    private static void print(List<Animal> animals, CheckTrait checker) {
        for (Animal animal : animals) {
            
            
            if (checker.test(animal)) {
                System.out.print(animal + " ");
            }
        }
        System.out.println();
    }
}
