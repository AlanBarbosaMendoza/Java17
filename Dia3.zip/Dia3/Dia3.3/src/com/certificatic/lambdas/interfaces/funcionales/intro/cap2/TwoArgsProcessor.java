package com.certificatic.lambdas.interfaces.funcionales.intro.cap2;
@FunctionalInterface
public interface TwoArgsProcessor<X> {
    X process(X arg1, X arg2);
}