/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.clase2.generics.wildcard;

/**
 *
 * @author alanbarbosamendoza
 */
public class Deportista extends Persona {
    
    private String nombre;
    private String deporte;
    
    public Deportista(String nombre, String deporte){
        super(nombre);
        this.nombre = nombre;
        this.deporte = deporte;
    }
    
    public void participaOlimpiadas(){
    
         System.out.println("Deportista participa en olipiadas");
    
    }

    
}
