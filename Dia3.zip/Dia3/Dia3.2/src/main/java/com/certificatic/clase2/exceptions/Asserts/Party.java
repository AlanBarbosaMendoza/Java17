/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.clase2.exceptions.Asserts;

/**
 *
 * @author alanbarbosamendoza
 */
 public class Party {
    public static void main(String[] args) {
        
       //PersonClassInvariant pci = new PersonClassInvariant();
       //pci.changeName("Pepe");
        boolean bandera = false;
        if(bandera){
            System.out.println("Bandera está prendida");
        }else{
            System.out.println("Bandera apagada");
            assert true : "La bandera está apagada"; 

        }
        
       int numGuests = -5;
       
       
       assert numGuests > 0;
       
       
        try {
            System.out.println("");
        } finally{
        
        }
       
       
       System.out.println(numGuests);
    }
 }

