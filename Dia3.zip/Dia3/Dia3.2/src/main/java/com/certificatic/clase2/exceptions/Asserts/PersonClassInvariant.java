/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.certificatic.clase2.exceptions.Asserts;

/**
 *
 * @author alanbarbosamendoza
 */
public class PersonClassInvariant {
    String name;
    String ssn;
    int age;
    
    private void checkAge()
    {
        assert age >= 18 && age < 150;
    }
    
    
    public void changeName(String fname)
    {
        checkAge();
        name=fname;
    }
}

