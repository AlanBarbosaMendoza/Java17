/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.clase2.exceptions.ResourcesStatements;

/**
 *
 * @author alanbarbosamendoza
 */
public class MyFileReader implements AutoCloseable {
   private String tag;
   public MyFileReader(String tag) { this.tag = tag;}
   
   @Override public void close() {
      System.out.println("Closed: "+tag);
   }
}

