/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.clase2.exceptions.ResourcesStatements;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author alanbarbosamendoza
 */
public class UsaMyFileReader {

    public static void main(String[] args) {
        UsaMyFileReader myFileReader = new UsaMyFileReader();
        myFileReader.ejecutaEjemplo1();
        //myFileReader.ejecutaEjemplo2();
    }

    public void ejecutaEjemplo1() {

        try (var bookReader = new MyFileReader("monkey")) {

            System.out.println("Try Block");
        } finally {
            System.out.println("Finally Block");

        }

    }

    public void ejecutaEjemplo2() {

        try (var bookReader = new MyFileReader("1"); var movieReader = new MyFileReader("2"); var tvReader = new MyFileReader("3");) {
            System.out.println("Try Block");
        } finally {
            System.out.println("Finally Block");
        }

    }

}
