/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.util;

/**
 *
 * @author alanbarbosamendoza
 */
public  class ImpuestosUtil {
    
    public static double calcularIva(double cantidad){
        
        return cantidad * 0.16;
        
    }
    
        public static double calcularIsr(double cantidad){
        
        return cantidad * .30;
        
    }
    
}
