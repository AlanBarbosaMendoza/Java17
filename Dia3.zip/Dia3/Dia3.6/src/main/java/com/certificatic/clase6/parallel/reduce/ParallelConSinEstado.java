/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.clase6.parallel.reduce;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 *
 * @author alanbarbosamendoza
 */
public class ParallelConSinEstado {

    public static void main(String[] args) {

        List<Integer> a = addValuesWithState(IntStream.range(1, 11).parallel());
        
        a.stream().forEach(System.out::println);
        
        System.out.println("**********");
        
        List<Integer> b = addValuesWithoutState(IntStream.range(1, 11).parallel());
        
         b.stream().forEach(System.out::println);
    }

    public static List<Integer> addValuesWithState(IntStream source) {
        var data = Collections.synchronizedList(new ArrayList<Integer>());
        source.filter(s -> s % 2 == 0)
                .forEach(i -> {
                    data.add(i);
                });  // STATEFUL: DON'T DO THIS!
        return data;
    }

    public static List<Integer> addValuesWithoutState(IntStream source) {
        return source.filter(s -> s % 2 == 0)
                .boxed()
                .collect(Collectors.toList());
    }

}
