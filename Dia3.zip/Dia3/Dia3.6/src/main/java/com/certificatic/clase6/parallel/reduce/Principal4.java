/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.clase6.parallel.reduce;

/**
 *
 * @author alanbarbosamendoza
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public class Principal4 {

    public static void main(String[] args) {
        List<Integer> gastos = new ArrayList<Integer>();
        int total = 0;
        gastos.add(100);
        gastos.add(200);
        gastos.add(300);
        for (int gasto : gastos) {
            total += gasto;
        }
        System.out.println(total);
    }
}
