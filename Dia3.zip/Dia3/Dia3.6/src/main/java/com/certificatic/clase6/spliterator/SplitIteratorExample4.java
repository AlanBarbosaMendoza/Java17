/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.clase6.spliterator;

/**
 *
 * @author alanbarbosamendoza
 */
import java.util.ArrayList;
import java.util.Spliterator;
public class SplitIteratorExample4 {
  public static void main(String[] args) {
    ArrayList<String> cars = new ArrayList<String>();
    cars.add("Maruthi");
    cars.add("BMW");
    cars.add("Benz");
    cars.add("Creta");
    cars.add("Nissan");
    
    Spliterator<String> s = cars.spliterator();
    while(s.tryAdvance((n) -> System.out.println(n)));
    
  }
}
