/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.clase6.parallel;

import java.util.List;

/**
 *
 * @author alanbarbosamendoza
 */
public class EjemploesLibroCertificacionParaleloFindAny {

    public static void main(String[] args) {
        
        //serial();
        paralelo();
    }

    private static void serial() {
        System.out.print(List.of(1, 2, 3, 4, 5, 6)
                .stream()
                .findAny().get());

    }

    private static void paralelo() {
        System.out.print(List.of(1, 2, 3, 4, 5, 6)
                .parallelStream()
                .findAny().get());

    }

}
