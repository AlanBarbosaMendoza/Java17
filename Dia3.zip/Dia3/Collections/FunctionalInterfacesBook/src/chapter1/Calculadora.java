/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chapter1;

/**
 *
 * @author alanbarbosamendoza
 */
@FunctionalInterface
public interface Calculadora {

    int operacion(int  x);
    
    // 1) x sumar 1;
    // 2) x restar 1;
    // 3) x multiplicar por 1

}

