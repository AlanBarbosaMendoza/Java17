package chapter12;

import chapter8.*;

class Car {

    String manu;
    String model;
    int mpg;

    public Car(String ma, String mo, int mp) {
        manu = ma;
        model = mo;
        mpg = mp;
    }

    public String toString() {
        return manu + " " + model + " gets " + mpg + " mpg";
    }
}
