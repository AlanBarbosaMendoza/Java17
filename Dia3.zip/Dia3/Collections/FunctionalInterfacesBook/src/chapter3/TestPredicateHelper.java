/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chapter3;

/**
 *
 * @author alanbarbosamendoza
 */
import static chapter3.PredicateHelper.result;
import java.util.function.*;

class TestPredicateHelper {

    public static void main(String[] args) {
        
        
        Predicate<Integer> p1 = x -> x > 2;
        
        Predicate<Integer> p4 = x -> x < 50;
        
        
        Predicate<String> p2 = s -> s.charAt(0) == 'H';
        
        
        result(p4, 30);
        result(p1, 1);
        result(p2, "Bye");
    }
}
