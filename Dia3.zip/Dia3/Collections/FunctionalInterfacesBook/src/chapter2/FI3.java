package chapter2;
@FunctionalInterface
public interface FI3 
{
    Integer method1();
}
