package chapter2.incorrect;
@FunctionalInterface
public interface FIVoid 
{
    void method1(int i);
}
