package chapter6;
import java.util.function.Consumer;
public class TestConsumer 
{
    private static int sum = 0;
    public static void main(String[] args)
    {
        System.out.println("Sum:: "+ sum);
        Consumer<Integer> con = x -> sum += x;
        System.out.println("Sum:: "+ sum);
        con.accept(4);
        System.out.println("Sum:: "+ sum);
        con.accept(5);
        System.out.println(sum);
    }
}
