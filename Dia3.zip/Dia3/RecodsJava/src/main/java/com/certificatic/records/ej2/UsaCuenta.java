/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.certificatic.records.ej2;

/**
 *
 * @author alanbarbosamendoza
 */
public class UsaCuenta {
    
    public static void main(String[] args) {
        Cuenta.afiliacionCuenta(123);
        Cuenta.banco = "Santander";
        
        Cuenta cuenta = new Cuenta("Perenganito", 1235);
        cuenta.nombre();
        
        
    }
    
}
