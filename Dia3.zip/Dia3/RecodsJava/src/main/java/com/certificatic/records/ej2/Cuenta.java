/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Record.java to edit this template
 */
package com.certificatic.records.ej2;

import java.time.LocalDate;





/**
 *
 * @author alanbarbosamendoza
 */
public record Cuenta(String nombre, int numero, LocalDate fechaApertura ) {

    public Cuenta(String nombre, int numero, LocalDate fechaApertura) {
        this.nombre = nombre;
        this.numero = numero;
        this.fechaApertura = fechaApertura;
    }
    
    public Cuenta(String nombre, int numero) {
        this(nombre, numero, LocalDate.now());
 
    }
    
    public static String banco = "BBVA";
    
    public void muestraFechaApertura(){
    
        System.out.println("Fecha Apertura : "+ fechaApertura);
    
    }
    
    public static void afiliacionCuenta(int cuenta){
    
        System.out.println("cuenta: "+ cuenta);
        
    }
    
    
    
    

}
