/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.lambdas.predicate;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

/**
 *
 * @author alanbarbosamendoza
 */
public class Principal {

    public static void main(String[] args) {

        List<Persona> lista = new ArrayList<>();
        Persona p1 = new Persona("pepe", "perez", 20);
        Persona p2 = new Persona("angel", "sanchez", 30);
        Persona p3 = new Persona("pepe", "blanco", 40);
        lista.add(p1);
        lista.add(p2);
        lista.add(p3);

        lista.stream().forEach(new Consumer<Persona>() {

            @Override
            public void accept(Persona p) {

                System.out.println(p.getNombre());

            }

        });

        Predicate<Persona> predicadoNombre = new Predicate<Persona>() {

            @Override
            public boolean test(Persona p) {

                return p.getNombre().equals("pepe");
            }

        };

        System.out.println("***** Usando Predicate*******");

        lista.stream().filter(predicadoNombre).forEach(p -> System.out.println(p.getApellidos()));

        System.out.println("***** Usando Predicated con lambda *******");

        lista.stream().filter(p -> p.getNombre().equals("pepe")).forEach(p -> System.out.println(p.getApellidos()));

    }

}
