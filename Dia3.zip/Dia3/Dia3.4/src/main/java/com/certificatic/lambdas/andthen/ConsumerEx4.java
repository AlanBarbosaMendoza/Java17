/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.lambdas.andthen;

/**
 *
 * @author alanbarbosamendoza
 */
import java.util.function.Consumer;

public class ConsumerEx4 {

    public static void main(String[] args) {

        Consumer<UserAccount> c1 = test -> test.auth();

        Consumer<UserAccount> c2 = test -> test.welcome();

        UserAccount user = new UserAccount("tran", "123");

        try {
            c1.andThen(c2).accept(user);
        } catch (Exception e) {

        }
    }

    public static class UserAccount {
        private String userName;
        private String password;

        public UserAccount(String userName, String password) {
            this.userName = userName;
            this.password = password;
        }

        public void auth() {
            if ("123".equals(password)) {
                System.out.println("Valid Account!");
            } else {
                throw new RuntimeException("Invalid Password");
            }
        }

        public void welcome() {
            System.out.println("Welcome! " + this.userName);
        }
    }
}