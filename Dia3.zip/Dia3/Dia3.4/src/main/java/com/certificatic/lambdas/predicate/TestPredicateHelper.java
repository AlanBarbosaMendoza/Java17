/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.lambdas.predicate;

/**
 *
 * @author alanbarbosamendoza
 */
import java.util.function.*;
import static com.certificatic.lambdas.predicate.PredicateHelper.result;

class TestPredicateHelper {

    public static void main(String[] args) {
        Predicate<Integer> p1 = x -> x > 2;
        Predicate<String> p2 = s -> s.charAt(0) == 'H';
        result(p1, 6);
        result(p2, "Hello");
    }
}
