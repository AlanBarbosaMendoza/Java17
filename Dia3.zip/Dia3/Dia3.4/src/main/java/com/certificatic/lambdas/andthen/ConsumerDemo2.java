/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.lambdas.andthen;

import java.util.function.Consumer;

/**
 *
 * @author alanbarbosamendoza
 */
public class ConsumerDemo2 {
    
    public static void main(String[] args) {
         
          Consumer<Integer> c1 = i -> System.out.println(5*i);
          Consumer<Integer> c2 = i -> System.out.println(5+i);
          
        /* andThen(Consumer<? super T> after) - Devuelve un Consumidor compuesto que realiza,
           en secuencia, esta operación seguida de la operación posterior.*/
           /**************************************************** *******/
           
         c1.andThen(c2).accept(4); // 20, 9
         System.out.println("");
         
         
         c2.andThen(c1).accept(5); //10, 25
         System.out.println("");
         c1.andThen(i -> System.out.println(3*i)).accept(4); // 20, 12 
    }
}
