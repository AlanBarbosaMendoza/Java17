package com.certificatic.lambdas.metodos.referenciados;

import java.util.Arrays;

/**
 * @author alanbarbosamendoza
 */
public class Methods {

    public static void sayStaticHello() {
        System.out.println("Hey!!! i'am a static hello!");
    }

    public void sayInstanceHello() {
        System.out.println("Hey!!! i'am a instance hello");
    }

    public static void main(String[] args) {
        
        
//Referencia a un método estatico
        System.out.println("Referencia a un método estatico");
    
        IHello staticRef = Methods::sayStaticHello;
        staticRef.sayHello();

        System.out.println("_________________________");
        
        
        
//Referencia a un método de un objeto
        Methods methods = new Methods();
        System.out.println("Referencia a un método de un objeto");
        IHello instanceRef = methods::sayInstanceHello;
        instanceRef.sayHello();
        System.out.println("_________________________");

//Referencia a un método de un objeto arbitrario
        System.out.println("Referencia a un método de un objeto arbitrario");

        String[] names = new String[]{"Oscar", "Alex", "Maria", "Samuel", "Perla", "Fausto"};
        Arrays.sort(names, String::compareToIgnoreCase);
        System.out.println("Hey!!! i'am a ordered array " + Arrays.toString(names));

        System.out.println("_________________________");
        
//Referencia a un constructor
        
      
        System.out.println("Referencia a un constructor");
        IHello hello = Hello::new;
        hello.sayHello();
        System.out.println("_________________________");
    }
}
