/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.clase4.peek;

/**
 *
 * @author alanbarbosamendoza
 */
import java.util.Arrays;
import java.util.List;

public class Principal2 {
    

    public static void main(String[] args) {

        List<String> lista = Arrays.asList("hola", "que", "tal", "cómo", "estas", "tu");
        
      
        
        lista.stream()
                .peek((cadena) -> {
                    
                    System.out.println("_________________________________________________");
                    System.out.println("***inicio****");
                    System.out.println(cadena);
                    System.out.println("****fin inicio****");
                }).filter((cadena) -> cadena.length()>3)
                .peek((cadena) -> {
                    System.out.println("-----filtro--------");
                    System.out.println(cadena);
                    System.out.println("-----fin filtro-----");

                })
                .map((cadena) -> cadena.toUpperCase()).
                peek((cadena) -> {
                    System.out.println(">>>>>>mayusculas>>>>>>");
                    System.out.println(cadena);
                    System.out.println(">>>>>>>fin mayusculas>>>>>>");
                    System.out.println("_________________________________________________");
                    System.out.println("");
                           

                }).forEach(System.out::println);

       
    }

}
