/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.lambdas.andthen;

import java.util.function.Consumer;

/**
 *
 * @author alanbarbosamendoza
 */
public class ConsumerDemo1 {
    
     public static void main(String[] args) {
          
           Consumer<String> consumer = s -> System.out.println(s);
           
           Consumer<String> consumerString = s -> System.out.println(s.toUpperCase());
           
           Consumer<Integer> intConsumer = i -> System.out.println(5*i);
           
           // accept() - Performs this operation on the given argument.
           /********************************************************/
           consumer.accept("Peter Milanovich");// Peter Milanovich
           consumerString.accept("High priority");// HIGH PRIORITY
           intConsumer.accept(4);//20
     }
}
