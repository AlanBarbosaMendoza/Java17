/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.clase4.peek;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 * @author alanbarbosamendoza
 */
public class PrincipalPersona {
    
    public static void main(String[] args) {
        
         List<Persona> lista = new ArrayList<>();
         lista.add(new Persona("Pedrito", 50));
         lista.add(new Persona("Juanito", 20));
         lista.add(new Persona("Panchito", 30));
         
        
        List<Persona> users =  lista.stream()
                .peek((persona) -> {
                    //persona.setNombre("Alan");
                    System.out.println("_________________________________________________");
                    System.out.println("***inicio****");
                    System.out.println(persona);
                    System.out.println("****fin inicio****");
                }).filter((persona) -> persona.getEdad()>3)
                .peek((persona) -> {
                    System.out.println("-----filtro--------");
                    System.out.println(persona);
                    System.out.println("-----fin filtro-----");

                }).collect(Collectors.toList());
        
        System.out.println("Lista original ");
        System.out.println(lista);
        
        System.out.println("Lista modificada ");
        System.out.println(users);
        
        
    }
    
}
