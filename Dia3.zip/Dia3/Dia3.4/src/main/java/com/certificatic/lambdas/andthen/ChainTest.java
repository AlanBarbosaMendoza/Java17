/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.lambdas.andthen;

/**
 *
 * @author alanbarbosamendoza
 */
import java.util.function.Consumer;
import java.util.function.Function;

public class ChainTest {
  public static void main(String[] args) {
    Consumer<Integer> addC = i -> Value.counterC += i;
    Consumer<Integer> showC = i -> System.out.println(i + "  :: " + Value.counterC + " :: ");
    Consumer<Integer> showD = i -> System.out.println("tercer andthen"+i );
    Consumer<Integer> showE = i -> System.out.println("cuarto andthen"+i );
    
    
    
    addC.andThen(showC).andThen(showD).andThen(showE).accept(2);

      System.out.println("****************************");
            
    
    Function<Integer, Integer> addF = i -> Value.counterF += i;
    Function<Integer, Integer> showF = i -> {
      System.out.print(i); return i;
    };
    addF.andThen(showF).apply(1);
  }
}


class Value {
  static Integer counterC = 1;
  static Integer counterF = 1;
}