/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.lambdas.streams;

/**
 *
 * @author alanbarbosamendoza
 */
public class Gasto {
    
    private String gasto;
    private int importe;
    
    public Gasto(String a, int i) {
        
        this.gasto = a;
        this.importe = i;
        
    }

    
    public String getGasto() {
        return gasto;
    }

  

    public int getImporte() {
        return importe;
    }

    
   
    
}
