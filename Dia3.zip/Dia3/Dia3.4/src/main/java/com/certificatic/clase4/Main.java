/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.clase4;

import java.util.Arrays;
import java.util.List;

/**
 *
 * @author alanbarbosamendoza
 */
public class Main {
    
    public static void main(String[] args) {
        String einstein = "La imaginación es más importante que el conocimiento";
        String[] splited = einstein.split("\\s+");

        // Collection to Iterate
        List<String> words = Arrays.asList(splited);
/*
        int count = 0;
        for(String w : words) {
            if(w.startsWith("i")) {
                count++;
            }
        }

      */


        long resultado = words.stream().filter(w -> w.startsWith("i")).filter(w -> w.length()>5).count();
        System.out.println("resultado :: "+ resultado);

    }
            
    
}
