/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.lambdas.andthen;

import java.util.Date;
import java.util.function.Consumer;

/**
 *
 * @author alanbarbosamendoza
 */
public class ConsumerPrimitiveSpecializationsDemo {
    
    public static void main(String[] args) {
         
          Consumer<Integer> c1 = i -> System.out.println(5*i);
          Consumer<Long> c2 = i -> System.out.println(i);
          Consumer<Double> c3 = i -> System.out.println(i+20.0);
          Consumer<Boolean> c4 = i -> System.out.println(i);
          
          c1.accept(10);
          c2.accept(new Date().getTime());
          c3.accept(50.20);
          c4.accept(10%2==0);      
    }
}
