/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.lambdas.andthen;

/**
 *
 * @author alanbarbosamendoza
 */
import java.util.function.Consumer;

public class ConsumerEx3 {
    
    public static void main(String[] args)  {
        
        Consumer<String> c = text -> System.out.println(text.toLowerCase());   
         
        c.andThen(c).accept("Hello");
    }
}
