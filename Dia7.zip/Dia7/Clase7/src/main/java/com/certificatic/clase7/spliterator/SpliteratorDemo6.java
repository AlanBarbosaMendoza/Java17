/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.clase7.spliterator;

/**
 *
 * @author alanbarbosamendoza
 */
import java.util.ArrayList;
import java.util.Spliterator;
public class SpliteratorDemo6 {
  public static void main(String[] args) {
    ArrayList<String> cars = new ArrayList<String>();
    cars.add("Maruthi");
    cars.add("BMW");
    cars.add("Benz");
    cars.add("Creta");
    cars.add("Nissan");
    cars.add("Toyota");

    
    Spliterator<String> s1 = cars.spliterator();
    Spliterator<String> s2 = s1.trySplit();
   
    
    System.out.println("Number of elements in SplitList1: " + s1.getExactSizeIfKnown());
    System.out.println("Values in SplitList1: ");
    s1.forEachRemaining(System.out::println);
    System.out.println("*****************");
    
    System.out.println("Number of elements in SplitList2: " + s2.getExactSizeIfKnown());
    System.out.println("Values in SplitList2: ");
    s2.forEachRemaining(System.out::println);
    
  }
}