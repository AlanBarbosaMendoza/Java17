/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.clase7.parallel.reduce;

/**
 *
 * @author alanbarbosamendoza
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public class Principal3 {

    public static void main(String[] args) {
        List<Integer> gastos = new ArrayList<Integer>();
        gastos.add(100);
        gastos.add(200);
        gastos.add(300);
        /*
       gastos.stream().reduce((acumulador, numero) -> {
            return acumulador + numero;
        }).ifPresent(System.out::println); */
        
        gastos.stream().reduce(Integer::sum).ifPresent(System.out::println);


    }
}