/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.clase7.parallel.custom.streams;

import static java.lang.Math.sqrt;
import java.util.stream.LongStream;

/**
 *
 * @author alanbarbosamendoza
 */
public class Main {

    public static void main(String[] args) {

        long begin = 100_000_000;
        long window = 100_000;
        getNumPrimes(begin, begin + window);
    }

    static void getNumPrimes(long begin, long end) {
        LongStream newStream = LongStream.range(begin, end)
        .filter(i -> isPrime(i));
        System.out.println("Num of primes = " + newStream.count());
    }

    static boolean isPrime(long n) {
        return LongStream.rangeClosed(2, (long) sqrt(n))
        .noneMatch(divisor -> n % divisor == 0);
    }

}
