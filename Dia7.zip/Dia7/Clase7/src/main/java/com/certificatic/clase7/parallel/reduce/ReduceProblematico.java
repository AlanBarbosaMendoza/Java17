/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.clase7.parallel.reduce;

import java.util.List;

/**
 *
 * @author alanbarbosamendoza
 */
public class ReduceProblematico {

    public static void main(String[] args) {
        problematico1();
        problematico2();

    }

    public static void problematico1() {

        System.out.println(List.of(1, 2, 3, 4, 5, 6)
                .parallelStream()
                .reduce(0, (a, b) -> (a - b)));  // PROBLEMATIC ACCUMULATOR

    }

    public static void problematico2() {

        System.out.println(List.of("w", "o", "l", "f")
                .parallelStream()
                .reduce("X", String::concat));  // XwXoXlXf

    }
}
