/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.clase7.parallel.collector;

/**
 *
 * @author alanbarbosamendoza
 */
public class Person {

    @Override
    public String toString() {
        return "Person{" + "city=" + city + ", firstName=" + firstName + ", lastName=" + lastName + ", age=" + age + '}';
    }

    public Person(City city, String firstName, String lastName, int age, String genero) {
        this.city = city;
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.genero = genero;
    }

    /**
     * @return the city
     */
    public City getCity() {
        return city;
    }

    /**
     * @param city the city to set
     */
    public void setCity(City city) {
        this.city = city;
    }

    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * @return the age
     */
    public int getAge() {
        return age;
    }

    /**
     * @param age the age to set
     */
    public void setAge(int age) {
        this.age = age;
    }
    
    public enum City {
        Belfast,
        Tulsa,
        Athens,
        London; }
    
        public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }
    
    private City city;
    private String firstName;
    private String lastName;
    private int age;
    private String genero;

    
}
