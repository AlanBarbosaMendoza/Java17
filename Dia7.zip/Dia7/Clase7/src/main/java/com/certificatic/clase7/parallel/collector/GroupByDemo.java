/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.clase7.parallel.collector;

/**
 *
 * @author alanbarbosamendoza
 */


import java.util.*; 
import java.util.function.Function; 
import java.util.stream.Collectors; 
  
public class GroupByDemo { 
    public static void main(String[] args) 
    { 
  
        // Get the List 
        List<String> g 
            = Arrays.asList("geeks", "for", "geeks", "valor", "valor","geeks"); 
  
        // Collect the list as map 
        // by groupingBy() method 
        // clave  -> valor
        // MX  -> México
        //Estructura que almacena información en pares
        Map<String, Long> result 
            = g.stream().collect( 
                Collectors.groupingBy( 
                    Function.identity(), 
                    Collectors.counting())); 
  
        // Print the result 
        System.out.println(result); 
    } 
} 