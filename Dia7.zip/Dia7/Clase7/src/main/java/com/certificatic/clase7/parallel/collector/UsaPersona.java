/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.clase7.parallel.collector;

import com.certificatic.clase7.parallel.collector.Person.City;
import java.util.ArrayList;
import java.util.Comparator;
import static java.util.Comparator.comparing;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.maxBy;
import static java.util.stream.Collectors.toList;

/**
 *
 * @author alanbarbosamendoza
 */
public class UsaPersona {

    public static void main(String[] args) {

        List<Person> people
                = List.of(new Person(City.Tulsa, "Joe", "Bloggs", 42, "Masculino" ),
                        new Person(City.Athens, "Amy", "Laverda", 21, "Femenino"),
                        new Person(City.London, "Bill", "Gordon", 33, "Masculino"),
                        new Person(City.Athens, "Eric", "Vincent", 33, "Masculino"),
                        new Person(City.Tulsa, "Eric", "Dunmore", 29, "Masculino"));

        //List<Person> myPpl = people.stream().collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
        //List<Person> myPpl = people.stream().collect(toList());
        // people.stream()
        //         .collect(maxBy(Comparator.comparing(Person::getAge))).ifPresentOrElse(m -> System.out.println(m + ", " + m.getAge() + ", isoldest"),
        //         () -> System.out.println("No Person of max age found"));
        //System.out.println(myPpl);
        
        Map<City, Optional<Person>> oldestByCity = people.stream().collect(groupingBy(Person::getCity, maxBy(comparing(Person::getAge))));
        
        //Map<City, Optional<Person>> oldestByCity = people.stream().collect(groupingBy(Person::getCity, maxBy(comparing(Person::getAge))));
        

        oldestByCity.forEach((k, v)
                -> {
            System.out.print(k + ":");
            System.out.println(v.isPresent()
                    ? v.get().getFirstName() + " age " + v.get().getAge()
                    : "No oldest person!");
        });

        Map<City, List<Person>> PplCitiesMap = people.stream()
                .collect(groupingBy(Person::getCity));
        
        Map<String, List<Person>> personasPorGenero = people.stream().collect(groupingBy(Person::getGenero));

        System.out.println(PplCitiesMap);
        
        System.out.println("personasPorGenero  :::: "+ personasPorGenero);
        
        imprimeNombre(obtenerMujeresVotantes(people));

    }
    
    
    
    private static List<Person> obtenerMujeresVotantes(List<Person> people ){
    
        return people.stream()
        		.filter(persona -> persona.getGenero().equalsIgnoreCase("femenino"))
        		.collect(toList());
    
    }
    
    private static void imprimeNombre(List<Person> mujeresVotantes){
    mujeresVotantes.stream()
    	.map(Person::getAge)
    	.forEach(System.out::println);
    
    }
    

}
