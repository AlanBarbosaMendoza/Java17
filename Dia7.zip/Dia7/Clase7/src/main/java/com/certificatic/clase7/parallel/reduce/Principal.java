/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.clase7.parallel.reduce;

/**
 *
 * @author alanbarbosamendoza
 */
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Principal {

    public static void main(String[] args) {

        Libro l1 = new Libro("El señor de los anillos", 1000);
        Libro l2 = new Libro("La fundacion", 500);
        Libro l3 = new Libro("El caliz de fuego", 600);

        ///////////Ejemplo 1
        Stream<Libro> st = Stream.of(l1, l2, l3);

        //ejemplo0(st);
        //ejemplo1(st);
        //ejemplo2(st);
        //ejemplo3(st);
        //ejemplo4(st);
        ejemplo5(st);

    }

    public static void ejemplo0(Stream<Libro> st) {
        st.forEach((l) -> System.out.println(l.getTitulo()));

        System.out.println("----------------------");
    }

    public static void ejemplo1(Stream<Libro> st) {
        Libro[] arrayLibro = st.toArray(Libro[]::new);

        for (int i = 0; i < arrayLibro.length; i++) {

            System.out.println(arrayLibro[i].getPaginas());
        }

    }

    public static void ejemplo2(Stream<Libro> st) {
        System.out.println("---------toList()-------------");
        List<Libro> lista1 = st.collect(Collectors.toList());

        for (Libro l : lista1) {

            System.out.println(l.getTitulo());
        }
    }

    public static void ejemplo3(Stream<Libro> st) {

        System.out.println("----------toSet()------------");
        Set<Libro> lista2 = st.collect(Collectors.toSet());

        for (Libro l : lista2) {

            System.out.println(l.getTitulo());
        }

    }

    public static void ejemplo4(Stream<Libro> st) {

        String resultado = st.map((l) -> l.getTitulo()).collect(Collectors.joining(","));

        System.out.println(resultado);

    }

    public static void ejemplo5(Stream<Libro> st) {

        Optional<Integer> resultado3 = st.map((l) -> l.getPaginas()).collect(Collectors.reducing(Integer::sum));

        System.out.println(resultado3.get());

    }
}
