/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.clase7.parallel.collector;

/**
 *
 * @author alanbarbosamendoza
 */
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class DemoMaxBy {

    public static void main(String[] args) {
        Stream<String> stream = Stream.of("4", "7", "25", "87");
        Optional<String> op = stream.collect(Collectors.maxBy(String::compareTo));
        if (op.isPresent()) {
            System.out.println(op.get());
        } else {
            System.out.println("Nothing!");
        }

        List<String> fruits = List.of("apple", "pear", "orange", "grapes");
        Optional<String> minElement = fruits.stream()
                .collect(Collectors.minBy(Comparator.naturalOrder()));
        System.out.println(minElement); //Optional[apple]
    }
}
