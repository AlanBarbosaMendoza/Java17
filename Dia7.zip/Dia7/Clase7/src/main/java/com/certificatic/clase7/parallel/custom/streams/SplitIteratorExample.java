/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.clase7.parallel.custom.streams;

/**
 *
 * @author alanbarbosamendoza
 */
import java.util.ArrayList;
import java.util.Spliterator;

public class SplitIteratorExample {

	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<>();

		list.add("A");
		list.add("B");
		list.add("C");
		list.add("D");
		list.add("E");
		list.add("F");
                list.add("G");
                list.add("H");
                list.add("I");
                list.add("J");
                

		Spliterator<String> sp1 = list.spliterator();
                System.out.println(" tamaño :: "+ sp1.estimateSize());
		Spliterator<String> sp2 = sp1.trySplit();
                
                Spliterator<String> sp3 = sp1.trySplit();
                
                Spliterator<String> sp4 = sp2.trySplit();

		sp1.forEachRemaining(System.out::println);

		System.out.println("========");

		sp2.forEachRemaining(System.out::println);
                
                
                System.out.println("========");

		sp3.forEachRemaining(System.out::println);
                
                System.out.println("========");

		sp4.forEachRemaining(System.out::println);
                
                
                    
	}

}
