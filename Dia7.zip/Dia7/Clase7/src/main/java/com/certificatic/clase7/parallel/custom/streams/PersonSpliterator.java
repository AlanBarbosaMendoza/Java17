/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.clase7.parallel.custom.streams;

/**
 *
 * @author alanbarbosamendoza
 */

import java.util.Spliterator;
import java.util.function.Consumer;



public class PersonSpliterator implements Spliterator<Person> {
	
	private final Spliterator<String> lineSpliterator;
	private String name;
	private int age;
	private String city;

	public PersonSpliterator(Spliterator<String> lineSpliterator) {
		this.lineSpliterator = lineSpliterator;
	}
	
	@Override
	public int characteristics() {
		return lineSpliterator.characteristics();
	}

	@Override
	public long estimateSize() {
		return lineSpliterator.estimateSize() / 3;
	}

	@Override
	public boolean tryAdvance(Consumer<? super Person> action) {
		if (this.lineSpliterator.tryAdvance(line -> this.name = line) &&
			this.lineSpliterator.tryAdvance(line -> this.age = Integer.parseInt(line)) &&
			this.lineSpliterator.tryAdvance(line -> this.city = line)){
			
			Person p = new Person(name, age, city);
			action.accept(p);
			return true;
		}
		
		return false;
	}

	@Override
	public Spliterator<Person> trySplit() {
		return null;
	}

}
