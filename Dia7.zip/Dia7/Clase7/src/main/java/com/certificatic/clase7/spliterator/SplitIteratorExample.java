package com.certificatic.clase7.spliterator;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author alanbarbosamendoza
 */
import java.util.ArrayList;
import java.util.Spliterator;
public class SplitIteratorExample {
  public static void main(String[] args) {
    ArrayList<String> cars = new ArrayList<String>();
    cars.add("Maruthi");
    cars.add("BMW");
    cars.add("Benz");
    cars.add("Creta");
    cars.add("Nissan");
    
    
    Spliterator<String> s = cars.spliterator();
    int values = Spliterator.ORDERED | Spliterator.DISTINCT | Spliterator.SIZED;
    
    System.out.println("Output of hasCharacteristics: " + s.hasCharacteristics(s.characteristics()));
    
    if(s.hasCharacteristics(Spliterator.ORDERED))
      System.out.println("Characteristic is Ordered");
    if(s.hasCharacteristics(Spliterator.SIZED))
      System.out.println("Characteristic is Sized");
    if(s.hasCharacteristics(Spliterator.IMMUTABLE))
      System.out.println("Characteristic is Immutable");
    
  }
}
