/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.clase7.parallel.reduce;

/**
 *
 * @author alanbarbosamendoza
 */
import java.util.ArrayList;
import java.util.List;

public class Principal5 {

    public static void main(String[] args) {
        List<String> nombres = new ArrayList<String>();
        nombres.add("juan");
        nombres.add("gema");
        nombres.add("maria");
        
        nombres.parallelStream().reduce(String::concat).ifPresent(System.out::println);
    }
}
