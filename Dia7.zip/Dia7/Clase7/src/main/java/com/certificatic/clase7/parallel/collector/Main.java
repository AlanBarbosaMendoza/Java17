/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.clase7.parallel.collector;

/**
 *
 * @author alanbarbosamendoza
 */

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class Main {
    public static void main(String[] args) {
        List<Integer> integers = Arrays.asList(1, 1, 2, 2, 2, 3, 4, 5, 5);
        List<Character> characters = List.of('a','a','a','a', 'b', 'c', 'c', 'c', 'd');

        showMostPopular(integers);
        showMostPopular(characters);
    }

    private static <T> void showMostPopular(List<T> list) {
        Optional<T> o = list.stream()
                .collect(new MostPopular<>());

        //System.out.println("Most popular element in [" + StringUtils.join(list, ",") + "]: ");
        o.ifPresent(System.out::println);
    }
}