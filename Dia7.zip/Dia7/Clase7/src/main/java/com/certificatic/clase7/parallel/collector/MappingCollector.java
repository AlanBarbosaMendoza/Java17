/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.clase7.parallel.collector;

/**
 *
 * @author alanbarbosamendoza
 */
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class MappingCollector {

    static List<Employee> employeeList
            = Arrays.asList(new Employee("Tom Jones", 45, 15000.00),
                    new Employee("Harry Andrews", 45, 7000.00),
                    new Employee("Ethan Hardy", 65, 8000.00),
                    new Employee("Nancy Smith", 22, 10000.00),
                    new Employee("Deborah Sprightly", 29, 9000.00));

    public static void main(String[] args) {
        List<String> employeeNames = employeeList.stream().collect(Collectors.mapping(Employee::getName, Collectors.toList()));
        
        System.out.println("List of employee names:" + employeeNames);

        Optional<Integer> maxAge = employeeList
                .stream()
                .collect(Collectors.mapping((Employee emp) -> emp.getAge(), Collectors.maxBy(Integer::compareTo)));
        System.out.println("Max Age: " + maxAge.get());

    }
}
