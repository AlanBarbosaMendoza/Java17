/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.clase7.parallel.collector;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 *
 * @author alanbarbosamendoza
 */
public class DemoGroupby {
    
    public static void main(String[] args) {
        List<Integer> numbers = List.of(1, 2, 3, 5, 5);

    Map<Integer, Long> result = numbers.stream()
      .filter(val -> val > 3)
      .collect(Collectors.groupingBy(i -> i, Collectors.counting()));

    
        System.out.println(result.size());

    result = numbers.stream()
      .collect(Collectors.groupingBy(i -> i,
        Collectors.filtering(val -> val > 3, Collectors.counting())));

        System.out.println(result.size());
    }
    
}
