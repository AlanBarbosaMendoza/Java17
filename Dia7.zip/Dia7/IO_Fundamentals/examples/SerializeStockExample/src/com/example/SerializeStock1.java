package com.example;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SerializeStock1 {

    public static void main(String[] args) {
        // Determine if we have file name for the Portfolio
        
        String ruta = "/Users/alanbarbosamendoza/NetBeansProjects/D84838GC10_labs/labs/13-IO_Fundamentals/examples/SerializeStockExample/src/com/example/salida";
  
        //Create a stock portfolio
        Stock s1 = new Stock("ORCL", 100, 32.50);
    
        
        System.out.println ("Before serializaton:\n" + s1 + "\n");
 /*
        // Write out the Portfolio
        try (FileOutputStream fos = new FileOutputStream(ruta);
                ObjectOutputStream out = new ObjectOutputStream(fos)) {
            out.writeObject(s1);
            System.out.println ("Successfully wrote Portfolio as an object");
        } catch (IOException i) {
            System.out.println("Exception writing out Portfolio: " + i);
        }
       */ 
       
        // Read the Portfolio back in
        try (FileInputStream fis = new FileInputStream(ruta);
                ObjectInputStream in = new ObjectInputStream(fis)) {
            Stock newP = (Stock)in.readObject();
            System.out.println ("Success: read Stock back in:\n" + newP);
        } catch (ClassNotFoundException | IOException i) {
            System.out.println("Exception reading in Portfolio: " + i);
        }
    }
}
