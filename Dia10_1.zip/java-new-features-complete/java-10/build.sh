[[ -f bin ]] && mkdir bin
javac *.java -d ./bin