module J9NewFeatures {
	requires jdk.incubator.httpclient;
}