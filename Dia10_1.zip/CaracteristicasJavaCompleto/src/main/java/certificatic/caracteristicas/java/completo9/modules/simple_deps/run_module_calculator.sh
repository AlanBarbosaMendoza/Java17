# To run we need to specify the modules path and the entry module name
$JAVA9_HOME/bin/java -p output/mlibs -m simplecalculator