/**
 * Using JDK manually built from main branch.
 *
 * To run: `java --enable-preview --source 21 InstanceMainMethodLauncher.java`
 */
class InstanceMainMethodLauncher {
	void main() {
		System.out.println("Hello world from an instance main method o/");
	}
}
