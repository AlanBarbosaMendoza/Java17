/**
 * This file defines the module.
 * We can define the modules it requires and the packages it exports.
 */
module mathapi {
	// requires java.base // default import

	// export any public class (visibility)
	exports com.github.wesleyegberto.mathapi;
}
