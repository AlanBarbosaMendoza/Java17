package com.github.wesleyegberto.provider;

public interface Calculator {
	int calculateUniverseMeaning();
}