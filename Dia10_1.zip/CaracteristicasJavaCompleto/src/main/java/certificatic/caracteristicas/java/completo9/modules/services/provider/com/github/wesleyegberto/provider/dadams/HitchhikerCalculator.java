package com.github.wesleyegberto.provider.dadams;

import com.github.wesleyegberto.provider.Calculator;

public class HitchhikerCalculator implements Calculator {
	public int calculateUniverseMeaning() {
		return 42;
	}
}
