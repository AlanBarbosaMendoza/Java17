/**
 * This file defines the module.
 * We can define the modules it requires and the packages it exports.
 */
module simplecalculator {
	// should be included in the modules path using -p flag
	requires mathlib;
}
