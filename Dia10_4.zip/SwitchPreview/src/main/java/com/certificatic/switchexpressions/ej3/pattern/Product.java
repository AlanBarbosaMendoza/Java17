
package com.certificatic.switchexpressions.ej3.pattern;

/**
 *
 * @author alanbarbosamendoza
 */
class Product {
    
}
