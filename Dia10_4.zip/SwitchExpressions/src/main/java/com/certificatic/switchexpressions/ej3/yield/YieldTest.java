/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.certificatic.switchexpressions.ej3.yield;

/**
 *
 * @author alanbarbosamendoza
 */


class YieldTest {
    
    public static void main(String[] args) {
        YieldTest test = new YieldTest();
        //test.whenSwitchingOnNumberOne_thenWillReturnString();
        test.whenSwitchingWithArrowNoDefaultOnNumberTwo_thenWillReturnString();
        //test.whenSwitchingWithArrowOnNumberTwo_thenWillReturnString();
        //test.whenSwitchingWithColonOnNumberTwo_thenWillReturnString();
    }

    enum Number {
        ONE, TWO, THREE, FOUR
    }

    
    void whenSwitchingOnNumberOne_thenWillReturnString() {
        Number number = Number.ONE;
        String message;
        switch (number) {
            case ONE:
                message = "Got a 1";
                break;
            case TWO:
                message = "Got a 2";
                break;
            default:
                message = "More than 2";
        }

        
    }

    
    void whenSwitchingWithArrowOnNumberTwo_thenWillReturnString() {
        Number number = Number.TWO;
        int x = 0;
        String message = switch (number) {
            case ONE -> {
                yield "Got a 1";
            }
            case TWO -> {
                System.out.println("");
                System.out.println("");
                yield "Got a 2";
            }
            default -> {
                yield "More than 2";
            }
        };

     
    }

    
    void whenSwitchingWithArrowNoDefaultOnNumberTwo_thenWillReturnString() {
        Number number = Number.TWO;
        String message = switch (number) {
            case ONE -> {
                yield "Got a 1";
            }
            case TWO -> {
                yield "Got a 2";
            }
            case THREE, FOUR -> {
                yield "More than 2";
            }
        };
        System.out.println("mensaje "+ message);
        
    }

    
    void whenSwitchingWithColonOnNumberTwo_thenWillReturnString() {
        Number number = Number.TWO;
        String message = switch (number) {
            case ONE:
                yield "Got a 1";
            case TWO:
                yield "Got a 2";
            default:
                yield "More than 2";
        };

        
    }

}
