/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.certificatic.switchexpressions.ej2;

/**
 *
 * @author alanbarbosamendoza
 */
public enum Season {

	Spring("Trees start growing and flowers bloom."),
	Summer("Rrees have full green leaves and some bear fruit."),
	Autumn("Leaves turn orange and eventually fall."),
	Winter("Plants are dormant");
	
	private String description;
	
	private Season(String description) {
		this.description = description;
	}

	public String getDescription() {
		return description;
	}

}
