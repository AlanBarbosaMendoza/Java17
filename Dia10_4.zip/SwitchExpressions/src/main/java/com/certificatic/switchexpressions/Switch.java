/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.certificatic.switchexpressions;

/**
 *
 * @author alanbarbosamendoza
 */


import java.util.Scanner;

public class Switch {

    public static void main(String[] args) {
        System.out.println("Digite o dia da semana: ");
        
        Scanner input = new Scanner (System.in);
        
        String dia = input.nextLine();
        
        input.close();
        
        String resultado = "";
        switch(dia){
            case "Segunda":
                resultado = "Dia útil";
                break;
            case "Tercera":
                resultado = "segundo dia útil";
                break;
            case "Cuarta":
                resultado = "Tercer dia útil";
                break;
            case "Quinta":
                resultado = "Cuarto dia útil";
                break;
            case "Sexta":
                resultado = "Sexto";
                break;
            case "Sábado":
                resultado = "último dia da semana!!!";
                break;
            default:
                resultado = "dia inválido";
        }
        
        System.out.println(resultado);
        
        System.out.println("\n");
        
        // segunda forma de fazer essa estrutura
        
        
        String resultado2 = "";
        resultado2 = switch (dia){
            case "Segunda", "domingo"  -> "Dia útil";
            case "Tercera" -> "Tercera boa";
            case "Cuarta" -> "Cuarta boa";
            case "Quinta" -> "quinta boa";
            case "sexta" -> "sexta boa";
            case "sábado" -> "sábado bom";
            default -> "dia inválido";
        
            };
        
        System.out.println(resultado2);
        System.out.println("\n");
        
        // também poderia ser de esta forma
        resultado = switch (dia){
            case "Segunda", "Terça", "Quarta", "Quinta", "Sexta" -> "DIA ÚTIL";
            case "Sábado", "Domingo" -> "FINAL DE SEMANA";
            default -> "Dia inválido";
        };
        
        System.out.println(resultado);
        
      
        
       }
    
}
