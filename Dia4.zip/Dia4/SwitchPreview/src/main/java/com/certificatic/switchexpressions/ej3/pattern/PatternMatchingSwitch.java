/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.certificatic.switchexpressions.ej3.pattern;

/**
 *
 * @author alanbarbosamendoza
 */
public class PatternMatchingSwitch {
    
    public static void main(String[] args) {
        
        PatternMatchingSwitch pattern = new PatternMatchingSwitch();
        Food food = new Food();
        pattern.consume(food);
    }
    
    public void consume(Product product){
        switch (product) {
            case (Food food && food.isFresh())-> food.eat();
            case (Drink drink) -> drink.pour();
            default -> throw new IllegalStateException("Unexpected value");
        }
    
    }
    
}
