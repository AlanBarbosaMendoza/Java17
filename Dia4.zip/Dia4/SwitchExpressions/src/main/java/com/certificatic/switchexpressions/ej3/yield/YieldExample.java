/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.certificatic.switchexpressions.ej3.yield;

/**
 *
 * @author alanbarbosamendoza
 */
public class YieldExample {

    public static void main(String[] args) {
        String greeting = "hi";

        int value = switch (greeting) {
            case "hi" -> {
                System.out.println("I am not just yielding!");
                yield 1;
            }
            case "hello" -> {
                System.out.println("Me too.");
                yield 2;
            }
            default -> {
                System.out.println("OK");
                yield -1;
            }
        };

        System.out.println("Salida :: " + value);

       
        /////  With traditional blocks
        int value2 = switch (greeting) {
            case "hi":
                System.out.println("I am not just yielding!");
                yield 1;
            case "hello":
                System.out.println("Me too.");
                yield 2;
            default:
                System.out.println("OK");
                yield -1;
        };

        System.out.println("Salida :: " + value2);
        
        
        
         ///
        int nota = 85;
        String calificacion = switch (nota / 10) {
            case 10, 9 -> "A";
            case 8 ->  "B";
            case 7 ->  "C";
            case 6 ->  "D";
            default -> "F";
        };

        System.out.println("La calificación es: " + calificacion);
        
        
        

    }

}
