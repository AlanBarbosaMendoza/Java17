/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.certificatic.switchexpressions.ej2;

/**
 *
 * @author alanbarbosamendoza
 */
public enum Suit {
	
	Clubs(4),
	Diamonds(3),
	Hearts(2),
	Spades(1);
	
	private int rank;

	private Suit(int rank) {
		this.rank = rank;
	}

	public int getRank() {
		return rank;
	}
	
}
