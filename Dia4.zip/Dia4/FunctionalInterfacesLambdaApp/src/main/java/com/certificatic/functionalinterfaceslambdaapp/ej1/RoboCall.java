/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.certificatic.functionalinterfaceslambdaapp.ej1;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author alanbarbosamendoza
 */
public class RoboCall {

    public static void robocall(String number) {
        
        System.out.println("Se ha llamado por telefono "+ number);
        /*Code to place an automated call.
  This code will connect to the phone system
  using the supplied number and place the call.
         */
    }

    public void robocallEveryPerson() {
        List<Person> list = gatherPersons();
        for (Person p : list) {
            String num = p.getPhoneNumber();
            RoboCall.robocall(num);
        }
    }

    public void robocallEligibleDrivers() {
        List<Person> list = gatherPersons();
        for (Person p : list) {
            if (p.getAge() >= 16) {
                String num = p.getPhoneNumber();
                RoboCall.robocall(num);
            }
        }
    }

    public void robocallEligibleVoters() {
        List<Person> list = gatherPersons();
        for (Person p : list) {
            if (p.getAge() >= 18) {
                String num = p.getPhoneNumber();
                RoboCall.robocall(num);
            }
        }
    }

    public void robocallLegalDrinkers() {
        List<Person> list = gatherPersons();
        for (Person p : list) {
            if (p.getAge() >= 21) {
                String num = p.getPhoneNumber();
                RoboCall.robocall(num);
            }
        }
    }

    /////////////Solución 1
    public  void robocallPersonOlderThan(int age) {
        List<Person> pl = gatherPersons();
        for (Person p : pl) {
            if (p.getAge() >= age) {
                String num = p.getPhoneNumber();
                RoboCall.robocall(num);
            }
        }
    }

    /////////////////
    private List<Person> gatherPersons() {
        List<Person> lista = new ArrayList<>();
        lista.add(new Person("Juanito", "Perez", 24, Gender.MALE, "juanito@gmail.com", "7774847267", "CDMX", "CDMX", "CDMX", "1234"));
        return lista;
    }

}
