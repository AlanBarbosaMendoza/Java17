/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.certificatic.functionalinterfaceslambdaapp.var;

/**
 *
 * @author alanbarbosamendoza
 */
class Demo8 {
 
    // method1 using var
    // as a return type
   // var method1() { return ("Inside Method1"); }
 
    // method2 using var for a
    // parameter
    //void method2(var a) { System.out.println(a); }
 
    public static void main(String[] args)
    {
 
        // create an instance
        Demo1 obj = new Demo1();
 
        // call method1
        var res = obj.method1();
 
    }
}
