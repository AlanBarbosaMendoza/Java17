/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.certificatic.functionalinterfaceslambdaapp.var;

import java.util.ArrayList;

/**
 *
 * @author alanbarbosamendoza
 */
public class Var {

     // instance variable
    // var p = 50;
    
    
    public static void main(String[] args) {
        var lista = new ArrayList<Persona>();
        lista.add(new Persona("pedro", "perez", 20));
        
         // int
        var x = 100;
 
        // double
        var y = 1.90;
 
        // char
        var z = 'a';
 
        // string
        var p = "tanu";
 
        // boolean
        var q = false;
 
        // type inference is used in var keyword in which it
        // automatically detects the datatype of a variable
        System.out.println(x);
        System.out.println(y);
        System.out.println(z);
        System.out.println(p);
        System.out.println(q);
        
        
        
         // local variable
        var w = 100;
 
        // print x to the console
        System.out.println(w);
        
      /*  
        // Generic list using var
        var<var> al = new ArrayList<>();
           
          // add elements
        al.add(10);
        al.add(20);
        al.add(30);
       
        // print the list
        System.out.println(al); */
      
      
      // declaration without
        // initialization
        //var variable;
         
          // This is also not valid
        //var variable = null;
        
        // var valor = (Person p) -> p.getAge() >= 16; // not permitted
    }
}
