/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.certificatic.functionalinterfaceslambdaapp.ej1;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author alanbarbosamendoza
 */
public class RoboCallInterface {

    public static void main(String[] args) {
        ///Opción 1
        EligiblePerson eTester = new DriverEligibilityTesterImpl();
        RoboCallInterface robocall = new RoboCallInterface();
        robocall.robocallEligible(eTester);
        ///// Opción 2
        robocall.robocallEligible(new EligiblePerson() {
            			 public boolean isEligible(Person p) {
                		return p.getAge() >= 16;  }  });
        //Opción 3
        robocall.robocallEligible((Person p) -> p.getAge() >= 16);
        
        

        
        

    }

    public  void robocallEligible(EligiblePerson tester) {
         List<Person> pl = gatherPersons();
        for (Person p : pl) {
            if (tester.isEligible(p)) {
                String num = p.getPhoneNumber();
                RoboCallInterface.robocall(num);
            }
        }
    }

    public static void robocall(String number) {
        
        System.out.println("Se ha llamado por telefono "+ number);

    }
    
    /////////////////
    private List<Person> gatherPersons() {
        List<Person> lista = new ArrayList<>();
        lista.add(new Person("Juanito", "Perez", 24, Gender.MALE, "juanito@gmail.com", "7774847267", "CDMX", "CDMX", "CDMX", "1234"));
        return lista;
    }

}
