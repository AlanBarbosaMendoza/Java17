/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.certificatic.functionalinterfaceslambdaapp.ej1;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author alanbarbosamendoza
 */
public class RoboCallPriorJ8 {

    public static void main(String[] args) {
        DriverEligibilityTester eTester = new DriverEligibilityTester();

        robocallEligible(eTester);
    }

    public static void robocallEligible(DriverEligibilityTester tester) {
        List<Person> pl = new ArrayList<>();
        pl.add(new Person("Juanito", "Perez", 24, Gender.MALE, "juanito@gmail.com", "7774847267", "CDMX", "CDMX", "CDMX", "1234"));
        
        for (Person p : pl) {
            if (tester.isEligible(p)) { // call the wrapped method
                String num = p.getPhoneNumber();
                RoboCall.robocall(num);
            }
        }
    }

    /////////////////
    private List<Person> gatherPersons() {
        List<Person> lista = new ArrayList<>();
        lista.add(new Person("Juanito", "Perez", 24, Gender.MALE, "juanito@gmail.com", "7774847267", "CDMX", "CDMX", "CDMX", "1234"));
        return lista;
    }

}
