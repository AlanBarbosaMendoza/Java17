/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.certificatic.functionalinterfaceslambdaapp.var;

/**
 *
 * @author alanbarbosamendoza
 */
class Demo1 {
 
    public static void main(String[] args)
    {
 
        // int
        var x = 100;
 
        // double
        var y = 1.90;
 
        // char
        var z = 'a';
 
        // string
        var p = "tanu";
 
        // boolean
        var q = false;
 
        // type inference is used in var keyword in which it
        // automatically detects the datatype of a variable
        System.out.println(x);
        System.out.println(y);
        System.out.println(z);
        System.out.println(p);
        System.out.println(q);
    }
    
    public int method1(){
        return 10;
    }
}
