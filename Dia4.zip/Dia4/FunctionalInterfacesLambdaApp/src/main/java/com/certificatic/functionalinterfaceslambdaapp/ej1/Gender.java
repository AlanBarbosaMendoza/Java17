package com.certificatic.functionalinterfaceslambdaapp.ej1;

/**
 * @author MikeW
 */
public enum Gender { MALE, FEMALE }
