/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.certificatic.functionalinterfaceslambdaapp.ej1;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author alanbarbosamendoza
 */
public class RoboCallP1 {

    public static void robocall(String number) {
        /*Code to place an automated call.
  This code will connect to the phone system
  using the supplied number and place the call.
         */
    }

    /////////////Solución 1
    public void robocallPersonOlderThan(int age) {
        List<Person> pl = gatherPersons();
        for (Person p : pl) {
            if (p.getAge() >= age) {
                String num = p.getPhoneNumber();
                RoboCallP1.robocall(num);
            }
        }
    }

 /*   void robocallEligibleDrivers() {
        robocallPersonOlderThan(16);
    }

    void robocallEligibleVoters() {
        robocallPersonOlderThan(18);
    }

    void robocallLegalDrinkers() {
        robocallPersonOlderThan(21);
    }*/

    public void robocallPersonsInAgeRange(int low, int high) {
        List<Person> pl = gatherPersons();
        for (Person p : pl) {
            if (low <= p.getAge() && high < p.getAge()) {
                String num = p.getPhoneNumber();
                RoboCall.robocall(num);
            }
        }
    }

    public final static int MAX = 100;
    public void robocallEligibleDrivers() {
        robocallPersonsInAgeRange(16, MAX);
    }

    public void robocallEligibleVoters() {
        robocallPersonsInAgeRange(18, MAX);
    }

    public void robocallLegalDrinkers() {
        robocallPersonsInAgeRange(21, MAX);
    }

    void robocallSelectiveService() {
        robocallPersonsInAgeRange(18, 26);
    }

    /////////////////
    private List<Person> gatherPersons() {
        List<Person> lista = new ArrayList<>();
        lista.add(new Person("Juanito", "Perez", 24, Gender.MALE, "juanito@gmail.com", "7774847267", "CDMX", "CDMX", "CDMX", "1234"));
        return lista;
    }

}
