/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.certificatic.functionalinterfaceslambdaapp.ej1;

/**
 *
 * @author alanbarbosamendoza
 */
public class DriverEligibilityTester {

    public boolean isEligible(Person p) {
        return p.getAge() >= 16;
    }
}
