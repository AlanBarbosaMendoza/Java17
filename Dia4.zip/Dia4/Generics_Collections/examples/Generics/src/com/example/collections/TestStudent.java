package com.example.collections;

public class TestStudent {
    public static void main(String[] args){
        Student student = new Student("John Doe", 1111, 3.5);
    
        System.out.println(student);
    }
}
