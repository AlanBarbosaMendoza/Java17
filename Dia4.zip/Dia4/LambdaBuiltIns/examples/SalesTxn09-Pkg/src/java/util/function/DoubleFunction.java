package java.util.function;

public interface DoubleFunction<R> {
    
    public R apply(double value);
}
