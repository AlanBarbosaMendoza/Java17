package zoo.animal.feeding;

public class Task {

    public static void main(String... args) {
        System.out.println("Hola Mundo2!");
    }
}