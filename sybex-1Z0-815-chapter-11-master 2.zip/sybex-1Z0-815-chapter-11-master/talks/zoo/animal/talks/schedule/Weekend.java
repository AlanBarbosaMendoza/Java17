package zoo.animal.talks.schedule;

public class Weekend {
}
