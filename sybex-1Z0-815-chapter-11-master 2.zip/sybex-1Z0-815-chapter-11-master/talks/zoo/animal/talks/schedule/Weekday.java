package zoo.animal.talks.schedule;

public class Weekday {
}
