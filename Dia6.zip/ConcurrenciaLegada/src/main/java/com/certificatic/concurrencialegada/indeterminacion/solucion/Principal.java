/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.concurrencialegada.indeterminacion.solucion;

import com.certificatic.concurrencialegada.indeterminacion.*;
import java.util.Random;

/**
 *
 * @author alanbarbosamendoza
 * Indeterminismo 
 * Sección crítica
 * 
 * Realizar la multiplicación de todos los elementos de un vector de enteros por 10 
 */
public class Principal extends Thread {
    private static int tam = 8;
    private static int[] vec = new int[tam];
    
    private int ini, fin;
    
    public Principal(int ini, int fin){
        this. ini = ini;
        this.fin = fin;
    
    }
    
    
    @Override
    public void run() {
        for (int i = ini; i < fin; i++) { 
           vec[i] *=  10;
        }
        
    }
    
    public static void main(String[] args) {
       Random rand = new Random(System.nanoTime());
       
       // Inicializamos el vector
        for (int i = 0; i < vec.length; i++) {
            vec[i] = rand.nextInt(10);
        }
        
        Principal h1 = new Principal(0,4);
        Principal h2 = new Principal(4,8);
        
        h1.start();
        h2.start();
        
        
        // No va a continuar hasta que el hilo 1 e hilo 2 hayan terminado.
        try {
            h1.join();
            h2.join();
        } catch (Exception e) {
        }
        
        // Mostramos los valores del vector
        for (int i = 0; i < vec.length; i++) {
            System.out.print(vec[i]+" ");
        }
        
        
        // La técnica para que no haya indeterminación, es decir para que no haya región crítica es:
        // vec = ( 1 2 3 4 5 6 7 8)
        // cada hilo toma una parte:
        // hilo 1 = 1 2 3 4
        // hilo 2 = 5 6 7 8 
        // zona crítica: es una parte en la que dos o más hilos acceden para modificar un atributo compartido. 
    }
    
    
    
}
