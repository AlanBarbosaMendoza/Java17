/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.concurrencialegada.indeterminacion.tiempo;

import java.util.Random;

/**
 *
 * @author alanbarbosamendoza
 */
public class Principal extends Thread {

    private static int tam = 4; // 800
    private static int[][] matriz = new int[tam][tam];

    private int inicio, fin;

    public Principal(int inicio, int fin) {
        this.inicio = inicio;
        this.fin = fin;
    }

    public void run() {

        for (int i = inicio; i < fin; i++) {
            for (int j = 0; j < matriz[0].length; j++) {
                matriz[i][j] *= 10;
            }
        }

    }

    public static void main(String[] args) {
        double tiempoInicio, tiempoFinal;
        
        Random rand = new Random(System.nanoTime());

        for (int i = 0; i < matriz.length; i++) {

            for (int j = 0; j < matriz[0].length; j++) {

                matriz[i][j] = rand.nextInt(10);

            }

        }

        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[0].length; j++) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println("");

        }

        tiempoInicio = System.nanoTime();
        
        
        Principal h1 = new Principal(0, 2); // 0, 400
        Principal h2 = new Principal(2, 4); // 400,800

        h1.start();
        h2.start();

        // No va a continuar hasta que el hilo 1 e hilo 2 hayan terminado.
        try {
            h1.join();
            h2.join();
        } catch (Exception e) {
        }

        tiempoFinal = System.nanoTime() - tiempoInicio;
        
        System.out.println("El tiempo final es: "+(tiempoFinal/1000_000) + " milisegundos");
        
        System.out.println(" Después de la multiplicación");
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[0].length; j++) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println("");

        }

    }

}
