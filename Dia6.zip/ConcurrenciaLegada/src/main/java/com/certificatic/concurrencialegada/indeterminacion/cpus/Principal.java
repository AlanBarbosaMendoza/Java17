/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.concurrencialegada.indeterminacion.cpus;

import com.certificatic.concurrencialegada.indeterminacion.tiempo.*;
import java.util.Random;

/**
 *
 * @author alanbarbosamendoza
 */
public class Principal extends Thread {

    private static int tam = 8;
    private static int[][] matriz = new int[tam][tam];

    private int inicio, fin;

    public Principal(int inicio, int fin) {
        this.inicio = inicio;
        this.fin = fin;
    }

    public void run() {

        for (int i = inicio; i < fin; i++) {
            for (int j = 0; j < matriz[0].length; j++) {
                matriz[i][j] *= 10;
            }
        }

    }

    public static void main(String[] args) {
        Runtime runtime = Runtime.getRuntime();
        int nucleos = runtime.availableProcessors();
        System.out.println(" Número de cpus disponibles : " + nucleos);

        Random rand = new Random(System.nanoTime());

        for (int i = 0; i < matriz.length; i++) {

            for (int j = 0; j < matriz[0].length; j++) {

                matriz[i][j] = rand.nextInt(10);

            }

        }

        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[0].length; j++) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println("");

        }

        Thread hilos[] = new Thread[nucleos];
        int rango = tam / nucleos;
        int start = 0;
        int finish = rango;

        for (int i = 0; i < nucleos; i++) {

            if (i != nucleos -1) {
                hilos[i] = new Principal(start, finish);
                hilos[i].start();
                start = finish;
                finish += rango;
            } else {
                hilos[i] = new Principal(start, finish);
                hilos[i].start();
            }

        }

        // No va a continuar hasta que el hilo 1 e hilo 2 hayan terminado.
        try {
            for (int i = 0; i < hilos.length; i++) {

                hilos[i].join();

            }
        } catch (Exception e) {
        }
        System.out.println(" :::::::::::: ");
        System.out.println(" Después de la multiplicación");
        System.out.println(" :::::::::::: ");
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[0].length; j++) {
                System.out.print(matriz[i][j] + "    ");
            }
            System.out.println("");

        }

    }

}
