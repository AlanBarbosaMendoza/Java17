/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.concurrencialegada.indeterminacion;

/**
 *
 * @author alanbarbosamendoza
 * Indeterminismo 
 * Sección crítica
 * 
 * cont = 10 * 10 = 100
 * cont = 100
 * h1  cont = 100 NO SE HA ESCRITO
 * h2  cont = 100 sí se escribe
 * h3  cont = 101 sí se escribe
 * 
 */
public class Principal extends Thread {
    private static int count = 0;

    @Override
    public void run() {
        for (int i = 0; i < 1000; i++) { //h1 cont = 100 
            count++;                     //h2 cont = 150
                                         //h1 200
                                         //h2 200
                                         //h3 cont = 201   
        }                                // h1 cont = 800
        
    }
    
    public static void main(String[] args) {
        Principal[] vec = new Principal[1000];
        
        for (int i = 0; i < vec.length; i++) {
            vec[i] = new Principal();
            vec[i].start();
        }
        
        
        
        try {
            for(int i = 0; i < vec.length; i++){
                vec[i].join();
                
            }
        } catch (Exception e) {
        }
        
        System.out.println("Count :: "+ count);
        
        
        
        
    }
    
    
    
}
