/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * Cerrojos

 */
package com.certificatic.concurrencialegada.indeterminacion.sincronizacion.cerrojos;

/**
 *
 * @author alanbarbosamendoza
 */
public class Principal implements  Runnable{

    private static int count = 0;
    private static Object object = new Object();
    
    @Override
    public void run() {
        // Inclusión mutua
        synchronized(object){ //para optimización se debe agregar aquí, cada hilo ejecuta 200 veces a la vez
         for (int i = 0; i < 1000; i++) {
            //synchronized(object){ // cerrojo Se le pregunta al cerrojo ¿Hay alguien dentro?
                 count++;         // Activo:h1    Cola: h2 h4 h3 (se quedan dormidos esperando su turno)
            }                     // Una vez que h1 termina se despiertan todos los hilos de la cola
                                  // es una carrera, el más rápido gana.
            
        }
    }
    
    public static void main(String[] args) {
        Runtime runtime = Runtime.getRuntime();
        int nucleos = runtime.availableProcessors();
        System.out.println("Nucleos :: "+ nucleos);
        Thread hilos[] = new Thread[1000];
        
        
        for (int i = 0; i < hilos.length; i++) {
            Runnable runnable = new Principal();
            hilos[i] = new Thread(runnable);
            hilos[i].start();
        }
       
        for (int i = 0; i < hilos.length; i++) {
            try {
                hilos[i].join();
            } catch (Exception e) {
            }
        }
        
        System.out.println("Contador final :: "+ count);
    }
    
    
    
    
}
