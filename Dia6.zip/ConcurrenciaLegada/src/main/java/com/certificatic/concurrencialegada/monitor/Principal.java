/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.concurrencialegada.monitor;

/**
 *
 * @author alanbarbosamendoza
 */
public class Principal implements Runnable {
    
    public static Monitor monitor = new Monitor();
    private int id;
    
    
    public Principal(int id){
        this.id = id;
    }
    
    
    

    @Override
    public void run() {
 
        /*
        monitor.inc();
        System.out.println(monitor.getCount());
        */
        
        
        int cont = monitor.inc();
        System.out.println(cont);
        
        monitor.ordenar(id);
        
        
    }
    
    public static void main(String[] args) {
        Runtime runtime = Runtime.getRuntime();
        int nucleos = runtime.availableProcessors(); // obtener los hilos lógicos que tiene nuestro equipo.
        
        Thread [] hilos = new Thread[nucleos];
        
        for(int i = 0; i < hilos.length; i++){
            Runnable run = new Principal(i);
            
            hilos[i] = new Thread(run);
            hilos[i].start();
        
        }
        
        
        for(int i = 0; i < hilos.length; i++){
            try {
                hilos[i].join();
            } catch (Exception e) {
            }
        
        }
        
        
        
    }
    
    
    
}
