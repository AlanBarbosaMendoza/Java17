/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.concurrencialegada.monitor;

/**
 *
 * @author alanbarbosamendoza
 * 
 * Los monitores son aquellas clases que todos sus métodos públicos son sinchronized.
 * Un monitor provee exclusión mutua a cada uno de los métodos
 * Por ejemplo: si llega hilo 1 al método X el resto de hilos no podrá ejecutar ningún otro método
 * 
 * 
 * 
 *  H5 EN EJECUCIÓN
 *  EN COLA: H2  H6
 */
public class Monitor {
    private int cont = 0;
    
    private int order = 0;
    
    public  synchronized  int inc(){  // Activo: h0 Cola: h1  Existe una sola cola en común por todos los métodos
    
        for (int i = 0; i < 20_000; i++) {
            cont++; //20_000
        }
        
        return cont;
    
    }
    
    
     /* Indeterminismo
    
    public  synchronized  void inc(){  // Activo: h0 Cola: h1  Existe una sola cola en común por todos los métodos
    
        for (int i = 0; i < 20_000; i++) {
            cont++; //20_000
        }
  
    
    }
    */
    public synchronized int getCount(){
        
        return cont;
    
    }
    
    //Exclusión mutua: sólo se pude ejecutar un hilo a la vez
    public synchronized void ordenar(int id){
        while(id != order){
            try {
                wait(); // se genera una cola diferente, tenemos 2 hilos
            } catch (Exception e) {
                e.printStackTrace();
            }
        
        }
    
        System.out.println("Soy el hilo : "+id);
        order++;
        notifyAll();
    
    }
    
}
