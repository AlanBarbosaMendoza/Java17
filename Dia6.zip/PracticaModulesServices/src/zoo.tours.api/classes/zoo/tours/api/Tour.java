package zoo.tours.api;

public interface Tour {

    String name();
    int length();
    Souvenir getSouvenir();

}
