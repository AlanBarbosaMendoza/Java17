module zoo.visitor {

    requires zoo.tours.api;
    requires zoo.tours.reservations;
}