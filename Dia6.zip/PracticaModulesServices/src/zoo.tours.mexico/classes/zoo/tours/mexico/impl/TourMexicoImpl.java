/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package zoo.tours.mexico.impl;

import zoo.tours.api.Souvenir;
import zoo.tours.api.Tour;

/**
 *
 * @author alanbarbosamendoza
 */
public class TourMexicoImpl implements Tour{

    @Override
    public String name() {
        return "tour por Mexico";
    }

    @Override
    public int length() {
        return 5;
    }

    @Override
    public Souvenir getSouvenir() {
        Souvenir souvenir = new Souvenir();
        souvenir.setDescription("Tequila");
        return souvenir;
    }
    
}
