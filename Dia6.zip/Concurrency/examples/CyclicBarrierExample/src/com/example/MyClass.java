/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author alanbarbosamendoza
 */
public class MyClass {

    public static void main(String[] args) {
        CyclicBarrier barrier = new CyclicBarrier(3);

        Thread thread1 = new Thread(() -> {
            System.out.println("Primera Tarea");
        });

        Thread thread2 = new Thread(() -> {
            System.out.println("Segunda Tarea");
        });

        Thread thread3 = new Thread(() -> {
            System.out.println("Tercera Tarea");
        });

        thread1.start();
        thread2.start();
        thread3.start();

        try {
            barrier.await();
        } catch (InterruptedException e) {
            e.getMessage();
        } catch (BrokenBarrierException ex) {
            Logger.getLogger(MyClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        // Continúa con la ejecución del hilo principal
    }
}
