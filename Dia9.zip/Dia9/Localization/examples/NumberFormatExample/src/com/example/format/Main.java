package com.example.format;

public class Main {

  public static void main(String[] args) {
    NumberTest.main(args);
  }  
}
