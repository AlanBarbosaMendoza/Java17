package com.example.format;



/**
 * 
 * @author alanbarbosamendoza
 * Método que realiza el desencriptado del password
 * 
 */
public class Main {

  public static void main(String[] args) {

  }
  
}
