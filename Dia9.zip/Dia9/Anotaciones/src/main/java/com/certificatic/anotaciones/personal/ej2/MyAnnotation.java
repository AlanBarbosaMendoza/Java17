/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.anotaciones.personal.ej2;

/**
 *
 * @author alanbarbosamendoza
 */
@interface MyAnnotation {
    String   value();
    String   name();
    int      age();
    String[] newNames();

}
