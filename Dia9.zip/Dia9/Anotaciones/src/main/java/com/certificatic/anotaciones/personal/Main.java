/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.certificatic.anotaciones.personal;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 *
 * @author alanbarbosamendoza
 */
public class Main {

    public static void main(String[] args) throws NoSuchFieldException {
        MyClass myClass = new MyClass();
        MyCustomAnnotation mca = myClass.getClass().getAnnotation(MyCustomAnnotation.class);
        System.out.println("studentName: " + mca.studentName());
        System.out.println("studentAge: " + mca.studentAge());
        System.out.println("studentAge: " + mca.stuAddress());

        Method[] methods = myClass.getClass().getDeclaredMethods();
        System.out.println("tamaño de methods"+methods.length);
        
        for (Method method : methods) {
            System.out.println("methods"+ method);
            if (method.isAnnotationPresent(Alan.class)) {
                Alan annotationAlan = method.getAnnotation(Alan.class);
                System.out.println("Anotación Alan : Nombre: " + annotationAlan.nombre());
            }
        }

    }

}
