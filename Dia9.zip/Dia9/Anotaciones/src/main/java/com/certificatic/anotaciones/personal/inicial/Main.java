/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.certificatic.anotaciones.personal.inicial;


import java.lang.annotation.Annotation;
import java.lang.reflect.Field;

/**
 *
 * @author alanbarbosamendoza
 */
public class Main {

    public static void main(String[] args) throws NoSuchFieldException {
        Person person = new Person("Paquito");
        
        Field field = person.getClass().getDeclaredField("name");
        if (field.isAnnotationPresent(MyAnnotation.class)) {
                MyAnnotation nombre = field.getAnnotation(MyAnnotation.class);
                System.out.println("edadMinima definida en anotación :"+nombre.value());
        }else{
            System.out.println("El atributo no está anotado");
        }
        
    }
}
