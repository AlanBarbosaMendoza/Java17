/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.anotaciones.safevarargs;

/**
 *
 * @author alanbarbosamendoza
 */
import java.util.ArrayList;
import java.util.List;
  
public class Geeks2<T> {
  
    private List<T> topics = new ArrayList<>();
  
    // Here by placing @SafeVarargs annotation
    // to add() method, we are ensuring to the
    // compiler that our action is safe.
    // That's why compiler will not throw
    // any warning message at the compile time.
    @SafeVarargs
    public final void add(T... toAdd)
    {   
        for (T topic : toAdd) {
            topics.add(topic);
        }
    }
  
    //@SuppressWarnings("unchecked")
    public static void main(String[] args)
    {
        Geeks2 geek = new Geeks2();
        geek.add("OOPS",
                 "COLLECTIONS",
                 "EXCEPTION-HANDLING");
        System.out.println(geek.topics);
    }
}
