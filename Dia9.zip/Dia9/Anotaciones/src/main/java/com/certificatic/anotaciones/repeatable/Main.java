/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.anotaciones.repeatable;

import java.lang.annotation.Annotation;

/**
 *
 * @author alanbarbosamendoza
 */
public class Main {
       public static void main(String[] args) {
       Annotation[] annotations = Man.class.getAnnotations();  
       System.out.println(annotations.length);
       Persons p1=(Persons) annotations[0];
       for(Person t:p1.value()){
           System.out.println(t.role());
       }
   }
}
