/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.anotaciones.safevarargs;

/**
 *
 * @author alanbarbosamendoza
 */
import java.util.ArrayList;
import java.util.List;
  
public class Geeks<T> {
  
    private List<T> topics = new ArrayList<>();
  
    // Here add() is a method with varargs of type T
    // Here T is unknown for
    // the compiler at the compile time
    // That's why It will throw unsafe
    // operation warning message
    
    public final void add(T... toAdd)
    {
        for (T topic : toAdd) {
            topics.add(topic);
        }
    }
  
    public static void main(String[] args)
    {
        Geeks geek = new Geeks();
        geek.add("OOPS",
                 "COLLECTIONS",
                 "EXCEPTION-HANDLING");
        System.out.println(geek.topics);
    }
}
