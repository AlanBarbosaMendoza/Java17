/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.anotaciones.safevarargs;

/**
 *
 * @author alanbarbosamendoza
 */
import java.util.ArrayList;
import java.util.List;
  
public class Geeksforgeeks2 {
  
    // Here we used @SafeVarargs annotation,
    // now we will not get any unchecked
    // or unsafe operations warning message
    // at compile time
  @SafeVarargs
  @SuppressWarnings("unchecked")
    private void print(List... topics)
    {
        for (List<String> topic : topics) {
            System.out.println(topic);
        }
    }
  
    
    public static void main(String[] args)
    {
        Geeksforgeeks2 obj = new Geeksforgeeks2();
        List<String> list = new ArrayList<String>();
        list.add("OOPS");
        list.add("COLLECTION");
        obj.print(list);
    }
}
