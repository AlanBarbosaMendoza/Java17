/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.anotaciones.personal.ej1;

/**
 *
 * @author alanbarbosamendoza
 * https://www.adictosaltrabajo.com/2015/08/10/crear-anotaciones-propias-en-java/
 * Las anotaciones son un método muy útil de añadir u obetner información de los elementos que están anotados. Además nos permiten acceder a ellos en tiempo de ejecución, con lo que los metadatos se pueden llegar a usar como variables internas para modificar el comportamiento del flujo del programa (como hemos visto).


 */

public class Main {

    public static void main(String[] args) {
        final AutomaticWeapon weapon = new AutomaticWeapon(30);
        final Operator operator = new Operator();
        operator.operate(weapon);
    }
}