/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.anotaciones.safevarargs;

/**
 *
 * @author alanbarbosamendoza
 */
import java.util.ArrayList;
import java.util.List;
  
public class Geeksforgeeks1 {
  
    // print is a method with variable argument
    private void print(List... topics)
    {
        for (List<String> topic : topics) {
            System.out.println(topic);
        }
    }
  
    public static void main(String[] args)
    {
        Geeksforgeeks1 obj = new Geeksforgeeks1();
        List<String> list = new ArrayList<String>();
        list.add("OOPS");
        list.add("COLLECTION");
        obj.print(list);
    }
}
