/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.certificatic.anotaciones.personal.inicial.uno;

import java.lang.reflect.Field;
import java.time.LocalDate;
import java.time.Month;
import java.time.Period;

/**
 *
 * @author https://www.aluracursos.com/blog/crear-anotaciones-en-java
 * 
 */
public class MainValidador {

    public static void main(String[] args) {
        Usuario usuario = new Usuario("Maria", "52902488033", LocalDate.of(2020, Month.JANUARY, 13));
        System.out.println(validador(usuario));
    }

    public static <T> boolean validador(T objeto) {
        Class<?> clase = objeto.getClass();
        for (Field field : clase.getDeclaredFields()) {
            System.out.println("field :: "+ field);
            if (field.isAnnotationPresent(EdadMinima.class)) {
                EdadMinima edadMinima = field.getAnnotation(EdadMinima.class);
                System.out.println("edadMinima definida en anotación :"+edadMinima);
                try {
                    field.setAccessible(true);
                    LocalDate fechaNacimiento = (LocalDate) field.get(objeto);
                    return Period.between(fechaNacimiento, LocalDate.now()).getYears() >= edadMinima.valor();
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
        }
        return false;
    }

}
