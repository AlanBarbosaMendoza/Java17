/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.certificatic.anotaciones.safevarargs;

/**
 *
 * @author alanbarbosamendoza
 */
import java.util.ArrayList;
import java.util.List;

public class SafeVarAnnotationExample2 {
    
    @SafeVarargs
    private void print(List...names) {
        for (List < String > name: names) {
            System.out.println(name);
        }
    }
    public static void main(String[] args) {
        SafeVarAnnotationExample2 obj = new SafeVarAnnotationExample2();
        List < String > list = new ArrayList < String > ();
        list.add("Ramesh");
        list.add("John");
        obj.print(list);
    }
}
