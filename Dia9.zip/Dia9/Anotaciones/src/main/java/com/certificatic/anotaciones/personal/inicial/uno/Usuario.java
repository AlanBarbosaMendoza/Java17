/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.certificatic.anotaciones.personal.inicial.uno;

import java.time.LocalDate;

/**
 *
 * @author alanbarbosamendoza
 */
public class Usuario {

    private String nombre;
    private String identidad;
    @EdadMinima(valor=17)
    private LocalDate fechaNacimiento;
    //getters e setters

    Usuario(String nombre, String identidad, LocalDate fechaNacimiento) {
        this.nombre = nombre;
        this.identidad = identidad;
        this.fechaNacimiento = fechaNacimiento;
    }
}
