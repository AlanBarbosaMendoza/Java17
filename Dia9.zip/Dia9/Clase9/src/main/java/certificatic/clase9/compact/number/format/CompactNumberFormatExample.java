/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package certificatic.clase9.compact.number.format;

/**
 *
 * @author alanbarbosamendoza
 */
import java.text.NumberFormat;
import java.util.Locale;
 
public class CompactNumberFormatExample {
 
    public static void main(String args[]) {
 
        NumberFormat nf = NumberFormat.getCompactNumberInstance(
                Locale.US, NumberFormat.Style.SHORT);
        
        System.out.println("NumberFormat.Style.SHORT:");
        System.out.println("Result: " + nf.format(10000));
        System.out.println("Result: " + nf.format(120300));
        System.out.println("Result: " + nf.format(2120000));
        System.out.println("Result: " + nf.format(1950000300));
        
        nf = NumberFormat.getCompactNumberInstance(
                Locale.US, NumberFormat.Style.LONG);
        
        System.out.println("\nNumberFormat.Style.LONG:");
        System.out.println("Result: " + nf.format(10000));
        System.out.println("Result: " + nf.format(120300));
        System.out.println("Result: " + nf.format(2120000));
        System.out.println("Result: " + nf.format(1950000300));
    }
}
