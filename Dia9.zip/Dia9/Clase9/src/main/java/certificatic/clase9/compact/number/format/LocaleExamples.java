/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package certificatic.clase9.compact.number.format;

import java.util.Locale;

/**
 *
 * @author alanbarbosamendoza
 */
public class LocaleExamples {

    public static void main(String[] args) {
        //Como puede ver, Locale.FRANCE tiene los valores fr y FR, mientras que Locale.FRENCH solo tiene el valor fr.
        Locale france = Locale.FRANCE;
        Locale french = Locale.FRENCH;
        System.out.println("inicio");
        System.out.println(france.getLanguage()); // fr
        System.out.println(france.getCountry()); // FR

        System.out.println(french.getLanguage()); // fr
        System.out.println(french.getCountry()); // null
        
        System.out.println("fin");
    }

}
