/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package certificatic.clase9.compact.number.format;

import java.text.CompactNumberFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;

/**
 *
 * @author alanbarbosamendoza
 */
public class CompactNumberFormatPersonalizada {

    public static void main(String[] args) {

        final String[] compactPatterns
                = {"", "", "", "0k", "00k", "000k", "0m", "00m", "000m",
                    "0b", "00b", "000b", "0t", "00t", "000t"};

        final DecimalFormat decimalFormat = (DecimalFormat) NumberFormat.getNumberInstance(Locale.GERMANY);

        final CompactNumberFormat customCompactNumberFormat
                = new CompactNumberFormat(decimalFormat.toPattern(),
                        decimalFormat.getDecimalFormatSymbols(), compactPatterns);

        System.out.println("Salida 1 :: " + customCompactNumberFormat.format(1000000));
        System.out.println("Salida 2 :: " + customCompactNumberFormat.format(20000000));

        String formattedNumber = customCompactNumberFormat.format(12345);
        System.out.println(formattedNumber); // Output: 12k

    }

}
