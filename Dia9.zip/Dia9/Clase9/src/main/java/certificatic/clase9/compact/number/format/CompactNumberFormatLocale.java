/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package certificatic.clase9.compact.number.format;

/**
 *
 * @author alanbarbosamendoza
 */
import java.text.NumberFormat;
import java.util.Locale;
 
public class CompactNumberFormatLocale {
 
    private static void printCompactNumberFormatLocale(long number) {
        NumberFormat nfDefault = NumberFormat.getCompactNumberInstance();
        NumberFormat nfUsLong = NumberFormat.getCompactNumberInstance(Locale.US, NumberFormat.Style.LONG);
        NumberFormat nfFrShort = NumberFormat.getCompactNumberInstance(Locale.FRANCE, NumberFormat.Style.SHORT);
        NumberFormat nfFrLong = NumberFormat.getCompactNumberInstance(Locale.FRANCE, NumberFormat.Style.LONG);
        NumberFormat nfChShort = NumberFormat.getCompactNumberInstance(Locale.CHINA, NumberFormat.Style.SHORT);
        NumberFormat nfChLong = NumberFormat.getCompactNumberInstance(Locale.CHINA, NumberFormat.Style.LONG);
        
        System.out.println("Compact Number Formatting for " + number + ":");
        System.out.println("Default:  " + nfDefault.format(number));
        System.out.println("US Long:  " + nfUsLong.format(number));
        System.out.println("FR Short: " + nfFrShort.format(number));
        System.out.println("FR Long:  " + nfFrLong.format(number));
        System.out.println("CH Short: " + nfChShort.format(number));
        System.out.println("CH Long:  " + nfChLong.format(number) + "\n");
    }
 
    public static void main(String[] arguments) {
        printCompactNumberFormatLocale(345600);
        printCompactNumberFormatLocale(23450000);
        printCompactNumberFormatLocale(1230000000);
    }
}
