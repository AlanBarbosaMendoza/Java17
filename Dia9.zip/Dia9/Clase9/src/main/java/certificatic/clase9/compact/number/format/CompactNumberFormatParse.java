/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package certificatic.clase9.compact.number.format;

/**
 *
 * @author alanbarbosamendoza
 */
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Locale;
 
public class CompactNumberFormatParse {
 
    public static void main(String[] args) throws ParseException {
        NumberFormat nf = NumberFormat.getCompactNumberInstance(
                Locale.US, NumberFormat.Style.SHORT);
        System.out.println("US/SHORT parsing:");
        System.out.println(nf.parse("1K"));
        System.out.println(nf.parse("1M"));
        System.out.println(nf.parse("1B"));
 
       nf = NumberFormat.getCompactNumberInstance(
                Locale.US, NumberFormat.Style.LONG);
        System.out.println("\nUS/LONG parsing:");
        System.out.println(nf.parse("1 thousand"));
        System.out.println(nf.parse("1 million"));
        System.out.println(nf.parse("1 billion"));
        /*
        nf = NumberFormat.getCompactNumberInstance(
                Locale.FRANCE, NumberFormat.Style.LONG);
        System.out.println("\nUS/LONG parsing:");
        System.out.println(nf.parse("1 mille"));
        System.out.println(nf.parse("1 million"));
        System.out.println(nf.parse("1 milliard"));
        
        */
    }
}
