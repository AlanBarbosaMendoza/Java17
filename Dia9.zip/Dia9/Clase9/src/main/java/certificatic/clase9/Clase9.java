/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package certificatic.clase9;

/**
 *
 * @author alanbarbosamendoza
 */
public class Clase9 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
