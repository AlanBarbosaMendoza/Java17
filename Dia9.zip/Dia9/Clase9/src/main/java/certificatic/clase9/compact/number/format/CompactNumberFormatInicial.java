/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package certificatic.clase9.compact.number.format;

import java.text.CompactNumberFormat;
import java.text.NumberFormat;
import java.util.Locale;

/**
 *
 * @author alanbarbosamendoza
 */
public class CompactNumberFormatInicial {

    public static void main(String[] args) {

        NumberFormat fmt = NumberFormat.getCompactNumberInstance(Locale.US, NumberFormat.Style.LONG);

        System.out.println(fmt.format(100));
        System.out.println(fmt.format(1000));
        System.out.println(fmt.format(10000));
        System.out.println(fmt.format(100000));

        NumberFormat fmtShort = NumberFormat.getCompactNumberInstance(Locale.US, NumberFormat.Style.SHORT);

        System.out.println(fmtShort.format(100));
        System.out.println(fmtShort.format(1000));
        System.out.println(fmtShort.format(10000));
        System.out.println(fmtShort.format(100000));

    }

}
