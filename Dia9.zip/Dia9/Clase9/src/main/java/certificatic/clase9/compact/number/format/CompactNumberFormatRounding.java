/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package certificatic.clase9.compact.number.format;

/**
 *
 * @author alanbarbosamendoza
 */
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.util.Locale;
 
public class CompactNumberFormatRounding {
 
    public static void main(String args[]) {
 
        NumberFormat nf = NumberFormat.getCompactNumberInstance(
                Locale.US, NumberFormat.Style.SHORT);
        
        System.out.println("\nResult: " + nf.format(123454));
        System.out.println("Result: " + nf.format(5156835));
        
        nf.setMinimumFractionDigits(2);   
        nf.setMaximumFractionDigits(2);
        System.out.println("\nResult: " + nf.format(123454));
        System.out.println("Result: " + nf.format(5156835));
        
        nf.setRoundingMode(RoundingMode.UP);
        System.out.println("\nResult: " + nf.format(123454));
        System.out.println("Result: " + nf.format(5156835));
        
        nf.setMinimumFractionDigits(1); 
        nf.setMaximumFractionDigits(1);        
        System.out.println("\nResult: " + nf.format(123454));
        System.out.println("Result: " + nf.format(5156835));
        
        nf.setRoundingMode(RoundingMode.DOWN);
        System.out.println("\nResult: " + nf.format(123454));
        System.out.println("Result: " + nf.format(5156835));
    }
}
