# javax-validation-testing
How to test javax.validation annotations

[Testing Javax Validation Constraints](https://merajzia.com/2020/08/30/testing-javax-validation/)
## Build
mvn clean verify
