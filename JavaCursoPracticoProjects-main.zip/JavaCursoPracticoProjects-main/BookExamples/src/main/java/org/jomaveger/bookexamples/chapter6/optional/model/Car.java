package org.jomaveger.bookexamples.chapter6.optional.model;

public class Car {
	
	private Insurance insurance;

	public Insurance getInsurance() {
		return insurance;
	}
	
	public void setInsurance(Insurance insurance) {
		this.insurance = insurance;
	}
}
