package org.jomaveger.bookexamples.chapter2;

public class App2 implements C, D, A {

    public static void main(String[] args) {
        new App2().doSth();
    }
}
