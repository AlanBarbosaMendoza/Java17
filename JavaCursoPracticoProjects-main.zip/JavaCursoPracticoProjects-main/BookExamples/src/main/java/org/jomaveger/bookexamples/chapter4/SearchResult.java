package org.jomaveger.bookexamples.chapter4;

public class SearchResult {
	
	public boolean found;
	public int index;
}
