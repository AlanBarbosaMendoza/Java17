package org.jomaveger.bookexamples.chapter6.optional.model;

public class Person {
	
	private Car car;

	public Car getCar() {
		return car;
	}
	
	public void setCar(Car car) {
		this.car = car;
	}
}
