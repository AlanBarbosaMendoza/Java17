package org.jomaveger.bookexamples.chapter1;

public class FirstExample {

	public static void main(String[] args) {
		System.out.println("Hello World!");
	}
}
