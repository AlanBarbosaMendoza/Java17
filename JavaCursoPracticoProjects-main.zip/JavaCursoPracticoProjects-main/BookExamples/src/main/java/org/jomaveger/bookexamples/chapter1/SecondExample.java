package org.jomaveger.bookexamples.chapter1;

public class SecondExample {
	
	public static void main(String args[]) {
		double a = 3.0, b = 4.0;
		double c = Math.sqrt(a * a + b * b);
		System.out.println("Hypotenuse is " + c);
	}
}
