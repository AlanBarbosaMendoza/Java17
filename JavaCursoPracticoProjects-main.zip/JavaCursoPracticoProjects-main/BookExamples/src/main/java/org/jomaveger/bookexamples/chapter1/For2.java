package org.jomaveger.bookexamples.chapter1;

public class For2 {
	public static void main(String args[]) {
		int n;
		for (n = 10; n > 0; n--)
			System.out.println("tick " + n);
		
		System.out.println("Final tick " + n);
		
		double x = 10000.0 / 3.0;
	}
}
