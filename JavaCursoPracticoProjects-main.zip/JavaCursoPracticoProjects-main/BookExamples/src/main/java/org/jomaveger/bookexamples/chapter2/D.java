package org.jomaveger.bookexamples.chapter2;

public interface D {
}
