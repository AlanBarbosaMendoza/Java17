package org.jomaveger.tictactoe;

public enum GameState {
	
	PLAYING, DRAW, CROSS_WON, NOUGHT_WON
}
