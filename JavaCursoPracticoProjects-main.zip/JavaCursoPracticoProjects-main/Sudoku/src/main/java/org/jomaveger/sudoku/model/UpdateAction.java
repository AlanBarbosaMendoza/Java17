package org.jomaveger.sudoku.model;

public enum UpdateAction {
    NEW_GAME,
    VIEW_SOLUTION,
    NO_SOLUTION
}