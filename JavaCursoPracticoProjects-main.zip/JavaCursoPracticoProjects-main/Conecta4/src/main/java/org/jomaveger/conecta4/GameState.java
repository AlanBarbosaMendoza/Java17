package org.jomaveger.conecta4;

public enum GameState {
	
	PLAYING, DRAW, BLACK_WON, RED_WON
}
