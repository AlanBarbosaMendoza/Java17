package org.jomaveger.conecta4;

public final class C4Location {
	public final int column, row;

	public C4Location(int column, int row) {
		this.column = column;
		this.row = row;
	}
}