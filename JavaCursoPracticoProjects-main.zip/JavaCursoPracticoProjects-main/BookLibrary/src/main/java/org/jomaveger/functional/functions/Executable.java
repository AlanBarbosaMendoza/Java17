package org.jomaveger.functional.functions;

@FunctionalInterface
public interface Executable {

	void exec();
}
