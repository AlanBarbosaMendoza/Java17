package org.jomaveger.lang.dbc.exceptions;

public class ContractViolationException extends RuntimeException {

	public ContractViolationException(String s) {
		super(s);
	}
}
