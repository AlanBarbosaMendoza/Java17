package org.jomaveger.structures;

public interface IBoundedQueue<T> extends IQueue<T> {
    
    boolean isFull();
}
