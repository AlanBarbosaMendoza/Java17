package org.jomaveger.game;

public interface Piece {
	
	Piece opposite();
}
