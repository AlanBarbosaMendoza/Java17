package org.jomaveger.functional.tuples;

public final class Nothing {
	
	public static final Nothing instance = new Nothing();

	private Nothing() {
	}
}
