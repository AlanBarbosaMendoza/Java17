package org.jomaveger.io.csv;

public interface CSVData {

	String[] getHeaders();
	
	String[] getLine();
}
