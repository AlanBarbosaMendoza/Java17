/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author alanbarbosamendoza
 */
import javax.annotation.processing.*;
import javax.lang.model.*;
import javax.lang.model.element.*;
import javax.tools.*;
import java.util.*;

@SupportedAnnotationTypes("PositiveNumber")
@SupportedSourceVersion(SourceVersion.RELEASE_17)
public class PositiveNumberProcessor extends AbstractProcessor {

    @Override
    public boolean process(Set<? extends TypeElement> annotations, RoundEnvironment roundEnv) {
        for (Element element : roundEnv.getElementsAnnotatedWith(PositiveNumber.class)) {
            if (element.getKind() == ElementKind.METHOD) {
                ExecutableElement method = (ExecutableElement) element;
                List<? extends VariableElement> parameters = method.getParameters();
                if (parameters.size() == 1) {
                    VariableElement parameter = parameters.get(0);
                    if (!isPositiveInteger(parameter)) {
                        processingEnv.getMessager().printMessage(Diagnostic.Kind.ERROR,
                                "@PositiveNumber annotation requires a method that accepts a positive integer.",
                                element);
                    }
                }else{
                processingEnv.getMessager().printMessage(Diagnostic.Kind.ERROR,
                                "@PositiveNumber annotation requires almost one params");
                }
            }
        }
        return true;
    }

    private boolean isPositiveInteger(VariableElement parameter) {
        // Aquí se puede implementar la lógica para verificar si el parámetro es un entero positivo
        // Este es un ejemplo básico, podría ser más complejo en una situación real
        return parameter.asType().toString().equals("int") || parameter.asType().toString().equals("java.lang.Integer");
    }
}

