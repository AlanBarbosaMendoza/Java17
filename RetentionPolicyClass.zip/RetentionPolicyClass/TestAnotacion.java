/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author alanbarbosamendoza
 */
public class TestAnotacion {
    
    @PositiveNumber
    public void metodo1(String x){
    
    }
    
}
