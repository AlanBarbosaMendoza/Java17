En Java, una anotación con política de retención de tipo CLASS es una anotación que se conserva en tiempo de compilación y se almacena en el archivo de clase correspondiente, pero no está disponible en tiempo de ejecución.

La retención de anotaciones en Java se refiere a cuándo y cómo están disponibles en tiempo de ejecución. Hay tres políticas de retención:

Retención de Fuente (SOURCE): Las anotaciones solo existen en el código fuente y se descartan durante la compilación. No están presentes en el bytecode.

Retención de Clase (CLASS): Las anotaciones se almacenan en el archivo .class generado durante la compilación, pero no están accesibles en tiempo de ejecución. Esto significa que, aunque el archivo de clase tiene la información de la anotación, no se puede acceder a ella dinámicamente mientras se ejecuta el programa.

Retención de Tiempo de Ejecución (RUNTIME): Las anotaciones están disponibles en tiempo de ejecución a través de reflexión, lo que permite que el código las lea y las utilice mientras se ejecuta el programa.

Las anotaciones con retención de tipo CLASS pueden ser útiles para herramientas de procesamiento de anotaciones en tiempo de compilación, ya que la información contenida en estas anotaciones está disponible para estas herramientas durante la compilación, pero no para el código en tiempo de ejecución.

Por ejemplo, se pueden usar para generar código adicional, realizar validaciones estáticas o realizar análisis estáticos del código durante el proceso de compilación. Sin embargo, debido a que no están disponibles en tiempo de ejecución, no se pueden acceder dinámicamente a través de reflexión durante la ejecución del programa.


Para ejecutar el ejemplo debemos de correr los siguientes comandos en una terminal:

javac PositiveNumber.java PositiveNumberProcessor.java
javac -processor PositiveNumberProcessor TestAnotacion.java